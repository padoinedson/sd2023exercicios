
a) Vantagens e desvantagens sobre outras empresas:
Vantagens: A AWS é frequentemente elogiada por sua extensa lista de serviços, confiabilidade, escalabilidade, e presença global. A empresa possui uma ampla variedade de serviços em nuvem, proporcionando flexibilidade para atender às diversas necessidades dos usuários.
Desvantagens: Em alguns casos, os custos podem ser mais altos em comparação com outras plataformas, especialmente para usuários que não otimizam adequadamente seus recursos. A curva de aprendizado pode ser íngreme para iniciantes devido à complexidade da oferta de serviços.


b) Tipos de serviços oferecidos:
Escalabilidade: A AWS oferece escalabilidade automática através de serviços como Auto Scaling, permitindo ajustes dinâmicos na capacidade conforme a demanda.
VM (Máquinas Virtuais): Amazon EC2 oferece instâncias de VM para uma ampla gama de requisitos.
Container (Docker): AWS suporta Docker com serviços como Amazon ECS (Elastic Container Service) e EKS (Elastic Kubernetes Service).


c) Localização dos servidores:
A AWS possui data centers em diversas regiões ao redor do mundo, permitindo a escolha de uma região específica para hospedar recursos e dados.


d) Custo:
Os custos da AWS variam dependendo do uso, e a estrutura de preços é modular. Pode ser mais caro em comparação com alguns concorrentes em certos casos, mas a flexibilidade nos planos de preços oferece opções para otimização.


e) Empresas que utilizam/contratam os serviços:
Muitas empresas, de startups a grandes corporações, utilizam a AWS. Exemplos incluem Netflix, Airbnb, Samsung, e mais.


f) Tipos de Segurança - SLA:
A AWS oferece uma série de ferramentas de segurança, como AWS Identity and Access Management (IAM), AWS Key Management Service (KMS), e possui uma ampla gama de certificações de segurança. O SLA (Acordo de Nível de Serviço) varia por serviço, garantindo uma alta disponibilidade.


g) Qual você contrataria? Justifique a sua escolha:
A escolha depende das necessidades específicas do projeto. Se a flexibilidade, a extensa gama de serviços, e a presença global forem cruciais, a AWS seria uma excelente escolha. No entanto, se os custos forem uma prioridade ou se houver requisitos específicos, pode ser útil comparar com outros provedores como o Azure ou o Google Cloud. A decisão final dependerá dos requisitos específicos do projeto, considerando fatores como escalabilidade, custo, e facilidade de uso.