#Bruno César Guisso de Souza - Hostinger

#OBS: o SCP não estava funcionando de maneira alguma nas VM's que eu estava testando por isso não inclui a print.


#Questões:

a) Vantagens e desvantagens sobre outras empresas:
Vantagens:
Preços competitivos em comparação com outras empresas de hospedagem.
Oferta de Cloud VM com recursos escaláveis.
Painel de controle intuitivo e fácil de usar.
Suporte técnico eficiente.
Diversidade de planos para atender diferentes necessidades.
Desvantagens:
Pode haver limitações em recursos avançados comparados a provedores mais especializados.
Alguns usuários relatam problemas de desempenho em picos de tráfego.

b) Tipos de serviços oferecidos: Escalabilidade, VM, Container (Docker):
A Hostinger oferece serviços de hospedagem que incluem:
Hospedagem Compartilhada: Ideal para sites pequenos a médios.
Cloud Hosting: Oferece recursos escaláveis e flexíveis, adequados para projetos de médio porte.
VPS Hosting (Virtual Private Server): Máquinas virtuais dedicadas, proporcionando maior controle sobre recursos.
Servidores Dedicados: Oferece servidores físicos exclusivos para maior desempenho e controle.
Hospedagem WordPress: Planos otimizados para sites WordPress.
Certificados SSL: Para segurança de dados transmitidos.
Registro de Domínio: Possibilidade de registrar e gerenciar domínios.
Email Hosting: Serviço de hospedagem de e-mail.
Hospedagem de E-commerce: Soluções específicas para lojas online.
Cloud VM e suporte a Containers (Docker): Permitindo flexibilidade e escalabilidade.

c) Localização dos servidores:
A Hostinger possui data centers em diversas regiões, como EUA, Europa, Ásia e Brasil, proporcionando baixa latência e melhor desempenho global.

d) Custo:
Os custos variam de acordo com o plano escolhido, mas geralmente são competitivos. A Hostinger muitas vezes oferece descontos para períodos de contratação mais longos.

e) Que empresas utilizam/contratam os serviços deste provedor:
Empresas de pequeno a médio porte, desenvolvedores individuais e proprietários de sites pessoais frequentemente utilizam os serviços da Hostinger.

f) Tipos de Segurança - SLA:
A Hostinger oferece medidas de segurança, incluindo certificados SSL, firewall, e backups regulares. O Acordo de Nível de Serviço (SLA) detalha as garantias de disponibilidade e desempenho oferecidas pela empresa.

g) Qual você contrataria? Justifique a sua escolha:
A escolha sempre depende das necessidades específicas do projeto. Se estiver buscando uma solução econômica para um projeto menor, deve-se considerar a Hostinger devido aos preços competitivos, A reputação do suporte técnico também seria um ponto a ser considerado. Porém diferente de outras Hospedagens Cloud, as VM's da Hostinger são virtualizadas assim existindo mais maquinas para serem disponibilizadas porém afetando um pouco do desempenho geral caso necessite de um grande poder de processamento. Problema que outras Cloud's como a Google não possuem. Porém o valor da Hostinger é bem mais acessível que qualquer outra hospedagem Cloud.