# PRINT DO SCP SEM SENHA

![biancaclound](/biancaclound.jpg)

#  REDEHOST 

## a) Vantagens e desvantagens sobre outras empresas

A RedeHost é uma das opções mais em conta de hospedagem do Brasil e, com a participação da Umbler, o processo de migração se torna bem rápido e intuitivo. Como o certificado SSL é grátis e a empresa baseia sua cobrança em um modelo de desconto progressivo (quanto maior o prazo do contrato, menor o pagamento proporcional), a alta disponibilidade e a performance do servidor compensam o investimento.

Além disso, a empresa é estabelecida no Brasil, o que aumenta seu desempenho no mercado do País: se a página carrega mais rapidamente que outros servidores, consequentemente o blog ou site hospedado terá maior performance e índices de ranqueamento em motores de busca, requisito imprescindível para potencializar uma estratégia de SEO.

Embora os custos dos planos sejam mais em conta, é possível encontrar preços mais acessíveis no mercado de hospedagem de sites e registro de domínios, principalmente em relação ao custo e ao benefício da solução.

A RedeHost é uma entre muitas empresas brasileiras que fornecem o serviço de hospedagem de qualidade. A crescente demanda dos clientes por comodidade e personalização mantém a relevância da criação de sites e blogs e do Marketing de Conteúdo no cenário do País.

## b) Tipos de servicos oferecidos: Escalabilidade, VM, Container (docker)

A RedeHost oferece um conjunto de soluções de hospedagem baseada em nuvem, que abrange desde a hospedagem de sites tradicional à hospedagem WordPress, PHP, Node. js, MySQL, MongoDB. Além disso, conforme já mencionamos, também fornece serviços completos de webmail, registro de domínio e revenda de hospedagem.

## c) Localização dos servidores

São Paulo

## d) Custo
Os custos podem variar conforme o serviço específico que o cliente necessitar.

* **ELÁSTICO**
Você pode contratar mais recursos conforme o seu site for crescendo.


R$ 24/mês       | R$ 34/mês      | R$ 55/mês      | R$ 190/mês     | R$ 270/mês 
:-------------- | :--------------| :------------- | :--------------|:--------------
**RAM 512 MB**  |**RAM 1 GB**    |**RAM 2 GB**    |**RAM 6 GB**    |**RAM 8 GB** 
**DISCO 1 GB**  |**DISCO 10 GB** |**DISCO 20 GB** |**DISCO 40 GB** |**DISCO 40 GB**
**CPU 2 Cores** |**CPU 2 Cores** |**CPU 3 Cores** |**CPU 4 Cores** |**CPU 6 Cores**

* **DEDICADO**
Um servidor inteiro para você instalar um ou mais sites conforme preferir.

R$ 189/mês  | R$ 378/mês | R$ 756/mês | R$ 1508/mês 
:----------------- |:------------------|:------------------|:-------------------
**RAM 3 GB**       |**RAM 6 GB**       |**RAM 12 GB**      |**RAM 24 GB**   
**DISCO 80 GB**    |**DISCO 120 GB**   |**DISCO 160 GB**   |**DISCO 320 GB** 
**CPU 2 x 2.4 Ghz**|**CPU 2 x 2.4 Ghz**|**CPU 4 x 2.4 Ghz**|**CPU 8 x 2.4 Ghz**

## e) Que empresas utilizam/contratam os serviços deste provedor

* VALE
* TIM
* DANONE
* FUNCAÇÃO ROBERTO MARINHO
* Acciona
* Itaú

## f) Tipos de Segurança - SLA

* 98,9% de uptime para hospedagem de sites em ambiente compartilhado;
* 99,9% o opcional de domínio;
de uptime para hospedagem em cloud;
registr
* Subdomínios ilimitados (exceto para o plano básico);
* Certificado SSL Let’s Encrypt;
* Migração de sites, emails e banco de dados para a Umbler com o Goodbye.host;
* Tráfego ilimitado;
* Configuração de variáveis de ambiente;
* Tarefas agendadas da CRON;
* Servidor de SMTP;
* Ajustes finos via SSH;
* Monitoramento de consumo de RAM, CPU e disco SSD em tempo real;
* Depuração de logs de erros com detalhamento e coleta em tempo real;
* Compartilhamento de acesso a sites, apps, emails e domínios com configuração individual do nível de permissão;
* CloudFlare para CDN gratuito;
* Envio de emails pelo SMTP por meio da integração ao SendGrid;
* 100% Solid State Drive (SSD);
* Infraestrutura isolada com configurações das variáveis do ambiente que garantem aos usuários independência no desempenho do servidor.

## g) Qual você contrataria? Justifique a sua escolha
A seleção do provedor de serviços de hospedagem é influenciada por diversos fatores, como requisitos de desempenho, escala, orçamento e preferências tecnológicas. Nesse contexto, optaria pela RedeHost para impulsionar ainda mais o crescimento desses serviços em nosso país. Destaco que os custos são flexíveis, ajustando-se conforme as necessidades do cliente, proporcionando a escolha de preços mais acessíveis à medida que as demandas aumentam e os planos se expandem.

A RedeHost apresenta uma série de vantagens, incluindo garantias de serviço (SLA), tais como 98,9% de uptime em hospedagem compartilhada, 99,9% em hospedagem em cloud, subdomínios ilimitados (exceto no plano básico), certificado SSL Let’s Encrypt e migração facilitada com o Goodbye.host. Além disso, oferece tráfego ilimitado, configuração de variáveis de ambiente, tarefas agendadas via CRON, servidor de SMTP, acesso SSH para ajustes precisos, monitoramento em tempo real de RAM, CPU e SSD, depuração de logs em tempo real, compartilhamento de acesso com permissões individuais e CDN gratuito com CloudFlare.

Destaco também a integração com SendGrid para envio de e-mails via SMTP, 100% SSD e infraestrutura isolada para um desempenho independente. Esses atributos reforçam a robustez e a abrangência dos serviços oferecidos pela RedeHost, tornando-a uma escolha sólida para atender às exigências específicas de hospedagem com qualidade, segurança e eficiência.



