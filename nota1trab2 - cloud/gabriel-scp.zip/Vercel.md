### Vercel

#### a) Vantagens e desvantagens sobre outras empresas

- **Vantagens**:
  - **Otimização de Desempenho**: A Vercel possui um sistema de otimização automática com edge caching e split testing.
  - **Integração Nativa com Next.js**: Um dos focos da Vercel é o Next.js (a mesma é mantenedora do framework).
  - **Facilidade de Uso**: Fácil integração com repositórios Git CI/CD.

- **Desvantagens**:
  - **Custo em Escala**: Mesmo que tenha um plano gratuito, os custos crescem bastante para aplicações em grande escala.
  - **Limitações de Backend**: Não é ideal para aplicações com backend complexo, já que seu foco é frontend.

#### b) Tipos de serviços oferecidos: Escalabilidade, Deploy de aplicações, Banco de dados

- **Escalabilidade**: Oferece escalabilidade automática com uma arquitetura focada em serverless.
- **Deploy**: Possui sistema próprio de deploy de aplicações.
- **Banco de dados**: Possui um serviço de banco de dados que pode ser utilizado.
- E mais...

#### c) Localização dos servidores

- A Vercel utiliza uma rede global de servidores, tirando proveito de uma arquitetura de edge computing.

#### d) Custo

- Oferece um plano gratuito com certas limitações. O preço das opções pagas varia de acordo com os recursos utilizados e pode aumentar significativamente para aplicações de grande escala.

#### e) Empresas que utilizam/contratam os serviços deste provedor

- Startups focadas em tecnologia e empresas que requerem alta performance no frontend são usuárias típicas. Empresas como Uber, Airbnb e Tripadvisor têm utilizado serviços da Vercel.

#### f) Tipos de Segurança - SLA

- Vercel oferece SSL/TLS automático e recursos de proteção DDoS.

#### g) Qual você contrataria? Justifique a sua escolha

- Caso a aplicação fosse focada no frontend, e fosse construída com NextJS, então a vercel seria uma excelente escolha, entretanto caso a aplicação lidasse com requisições mais complexas iria escolher algo como AWS ou GCP.