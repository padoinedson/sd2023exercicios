---------------------------------------------OpenStack--------------------------------------------------
<<https://www.openstack.org>>

Segundo a OpenStack: OpenStack é um sistema operacional em nuvem que controla grandes conjuntos de recursos de computação, armazenamento e rede em um datacenter, todos gerenciados e provisionados por meio de APIs com mecanismos de autenticação comuns.

Q1 - Vantagens do OpenStack:
        Código aberto a personalização: O OpenStack é mantido por sua comunidade o que o torna aberto a personalização.
        Grátis: Como o OpenStack é mantido por sua comunidade ele também é grátis.
        Serviços: Possui grande quantidade de tipos de serviços e ferramentas, facilitando a expansão e personalização da funcionalidade da Nuvem
        Multi-Nuvem: Gerenciamento de nuvens públicas, privadas e híbridas.
        Suporte da comunidade: Possui suporte a comunidade, onde pode-se tirar dúvidas sobre os serviços.
	Escalável: Permite o usuário dimensionar sua infraestrutura de acordo com a demanda.

     Desvantagens do OpenStack:
	Complexidade: Sua configuração e administração é complexa, exigindo conhecimento avaçado.
	Hardware: Dependendo da aplicação, requer um hardware melhor.
	Integração de Seviços: Em contrapartida ao grannde números de serviços, eles são dificeis de serem integrados, exigindo um pouco mais de esforço.

• Q2 - Nova: Serviço de computação que gerencia máquinas virtuais (VMs) e instâncias. 
       Zum: Gerenciamento de conteiners.
       Swift:  Projetado para armazenar e recuperar grandes quantidades de dados não estruturados. 
       Cinder: Serviço de armazenamento de blocos. Ele oferece volumes de armazenamento persistentes que podem ser anexados a VMs.
       Neutron: Neutron é o serviço de rede, fornecendo a capacidade de criar e gerenciar redes, sub-redes, roteadores e endereços IP. 
       Glance: Glance é o serviço de imagens. Ele permite que os usuários descubram, registrem e obtenham imagens de máquinas virtuais. 
       Keystone: Keystone é o serviço de identidade, responsável pela autenticação e autorização em todos os serviços do OpenStack. 
       Heat: Heat é o serviço de orquestração, permitindo que os usuários definam e provisionem recursos de infraestrutura usando modelos. 
       Trove: Trove é o serviço de banco de dados. 
       Zaqar: Zaqar é o serviço de mensagens, que fornece uma API de mensagens e notificações para conectar vários serviços e aplicativos. 
       Barbican: Barbican é o serviço de gerenciamento de chaves. Ele é usado para proteger dados sensíveis, como chaves de criptografia, segredos e certificados.

Q3 - O OpenStack possui servers distribuídos por todos os continentes.

Q4 - Grátis, o OpenStack é gerenciado pela sua comunidade.

Q5 - PayPal, Adobe, Walmart, Cern, SAP, entre outras.

Q6 - Serviço Keystone responsável por toda a parte de autenticação e autorização dos serviços, criptografia TSL/SSL responsável pela comunicação, Barbican responsável de proteger dados sensíveis, chaves, segredos, etc..

Q7 - O openStack é possui uma grande gama de serviços e ferramentas, além de ser grátis, possuindo quesitos parecidos com grandes empresas com o a AWS, além de que é escalável e tem tutoriais e ajuda de sua comunidade, porém é bem complexo quanto configuração e administração e ode ter grande consumo de hardware, então eu recomendaria para empresas que possuem uma equipe que tem grande conhecimento e um investimento apertado, porém se ela tem um investimento maior mesmo com um time com grande conhecimento eu recomendaria algum outro como a AWS, eu particularmente, mesmo sem tanto conhecimento tentaria me aventurar por causa do preço e pelos tutoriais de ensinamento e a comunidade que poderia ajudar.