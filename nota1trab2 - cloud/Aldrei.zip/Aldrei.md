# CLOUD
    RedHat: https://www.redhat.com

## EXERCÍCIOS
a) Vantagens e desvantagens sobre outras empresas:
    
    Vantagens:
        Red Hat Enterprise Linux: É uma distribuição Linux, conhecida por sua estabilidade e conformidade com padrões de segurança, sendo uma escolha popular para ambientes corporativos.
        Open Source: A Red Hat contribui ativamente para projetos de código aberto.
        Ferramentas de gerenciamento: A Red Hat fornece ferramentas de gerenciamento, como o Red Hat Ansible, facilitando a automação e a administração eficiente de sistemas em ambientes complexos.
        Parcerias estratégicas: As parcerias, especialmente com a IBM, ampliam a oferta de soluções integradas e suporte.
        Suporte empresarial de Qualidade: Oferece um suporte empresarial sólido para suas soluções, proporcionando confiabilidade e tranquilidade para as organizações.
    Desvantagens:
        Custo Mais Elevado: Os produtos da Red Hat, principalmente os relacionados ao suporte para o RHEL, tem um custo mais elevado em comparação com alternativas.
        Políticas de Licenciamento Complexas: Algumas organizações podem achar as políticas de licenciamento da Red Hat complexas ou restritivas.
        Distribuições Gratuitas: Em um cenário onde distribuições Linux gratuitas, como CentOS ou Ubuntu Server, oferecem desempenho satisfatório, a preferência por soluções de custo zero pode impactar a escolha da Red Hat.
        Sistema Pesado: O RHEL pode resultar em sistemas mais pesados para casos de uso que demandam uma abordagem mais leve e modular.

b) Tipos de servicos oferecidos: Escalabilidade, VM, Container (docker):

    Escalabilidade:
        O Red Hat Enterprise Linux é conhecido por sua escalabilidade, suportando desde implementações em servidores individuais até ambientes de data center de grande escala. O kernel Linux utilizado pelo RHEL é otimizado para desempenho e pode ser ajustado para atender a requisitos específicos de carga de trabalho.
    VMs:
        O Red Hat Virtualization permite a criação e o gerenciamento de máquinas virtuais.
    Container:
        Red Hat OpenShift é uma plataforma de containers Kubernetes empresarial que simplifica o desenvolvimento; há também o Atomic Host que é uma versão do RHEL otimizada para containers, fornece uma base leve e segura para implantações de containers.

c) Localização dos servidores:
    Não possui seus próprios servidores da mesma forma que provedores de nuvem, mas disponibiliza seus softwares e serviços para serem usados em diferentes lugares, como servidores locais e nuvens públicas ou privadas.

d) Custo:
    A Red Hat geralmente utiliza um modelo de assinatura para fornecer suporte, atualizações de segurança e acesso a recursos adicionais. Os custos associados às assinaturas variam com base nas características específicas dos produtos e serviços escolhidos.

e) Que empresas utilizam/contratam os serviços deste provedor:
    PayPal, DreamWorks Animation, FedEx, Verizon, Walmart, UBS.

f) Tipos de Segurança - SLA:
    Suporte Técnico:
        A Red Hat geralmente define níveis de suporte técnico, que podem variar desde o suporte básico até opções mais avançadas, dependendo do produto ou serviço adquirido.
    Disponibilidade:
        Em ambientes onde a Red Hat fornece serviços de nuvem ou hospedagem, o SLA pode definir os padrões de disponibilidade, indicando o tempo de atividade mínimo esperado.
    Correções:
        Aborda como e com que frequência a Red Hat fornecerá atualizações, correções de segurança e novas versões dos produtos.
    Desempenho:
        Em casos em que a Red Hat fornece soluções de software, o SLA pode estabelecer compromissos de desempenho para garantir que o software atenda a determinadas especificações.
    Segurança:
        O SLA pode incluir compromissos relacionados à segurança, como a rapidez com que a Red Hat responde a vulnerabilidades conhecidas e fornece correções.
    Atualização e Upgrade:
        O SLA pode abordar a política de atualização e upgrade, incluindo se há custos associados a migrações para versões mais recentes.

g) Qual você contrataria? Justifique a sua escolha:
    Pessoalmente eu contrataria a AWS, devido a sua confiabilidade, sendo utilizada por diversas empresas e por sua ampla variedade de serviços, sua documentação e suporte com uma comunidade ativa de usuários.

### ALDREI CASALINI RIGOLI