# Avaliação de Serviços de Cloud - Microsoft Azure

## Análise de Requisitos

### a) Vantagens e Desvantagens

**Vantagens:**
- Integração com Produtos Microsoft: Excelente integração com produtos Microsoft como Windows Server, Active Directory e SQL Server.
- Ampla Gama de Serviços: Oferece uma ampla variedade de serviços de computação, armazenamento, bases de dados, IoT, IA, entre outros.
- Suporte Empresarial: Opções de suporte extensivas e um ecossistema de parceiros vasto.
- Híbrido por Design: Oferece capacidades híbridas que facilitam a integração com data centers locais.

**Desvantagens:**
- Complexidade: A ampla variedade de serviços pode ser complexa para gerenciar.
- Custo: Pode se tornar caro dependendo dos serviços e recursos que você utiliza. O modelo de precificação também pode ser complexo.

### b) Tipos de Serviços Oferecidos

- Escalabilidade: Autoescalabilidade para VMs, bancos de dados e outros serviços.
- VMs: Máquinas virtuais personalizáveis com vários tipos de SO.
- Container (Docker): Suporte para Kubernetes através do Azure Kubernetes Service (AKS).

### c) Localização dos Servidores

Data centers em várias regiões globais, incluindo América do Norte, Europa, Ásia, Austrália e mais.

### d) Custo

- Modelos de precificação variáveis com base no tipo de serviço, recursos alocados e localização do data center.
- Calculadora de custos disponível para estimar despesas.

### e) Empresas que Utilizam

Empresas de vários setores, incluindo: Walmart, GE Healthcare, Adobe, HP, Johnson Controls, entre outras.

### f) Tipos de Segurança - SLA

- Complacência com várias normas internacionais de segurança e privacidade, como GDPR, ISO 27001, HIPAA.
- SLAs que garantem alta disponibilidade, variando de 99,9% a 99,99% dependendo do serviço.

### g) Qual Você Contrataria?

Escolheria o Azure principalmente devido à sua integração robusta com outros produtos Microsoft, o que é crítico para ambientes empresariais que já dependem de soluções Microsoft. A flexibilidade na escolha de diferentes serviços e a presença global também são fatores decisivos para a minha tomada de decisão.

### Docker file do cliente e do server utilizados no print do scp
![Dockerfile client/server](image.png)

### Docker compose utilizado para subir os containers
![Docker compose](image-1.png)