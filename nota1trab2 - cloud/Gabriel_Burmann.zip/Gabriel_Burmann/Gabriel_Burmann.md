A Salesforce é conhecida principalmente por seus serviços de Customer Relationship Management (CRM) e oferece uma variedade de soluções em nuvem, ou seja, uma visão única e compartilhada de cada cliente. Assim, você desenvolve sistemas de forma rápida e eficiente, em diferentes idiomas e para acesso em dispositivos variados.


a) Vantagens e desvantagens sobre outras empresas:

   Vantagens: 
-Salesforce é uma plataforma líder em CRM, conhecida pela sua flexibilidade e facilidade de personalização;
-Integração com outras ferramentas; 
-O ambiente é unificado e garante que as equipes de TI e as organizações façam o desenvolvimento com criadores a partir de serviços integrados, ferramentas profissionais e sem código;
-Alto investimento em medidas de segurança para proteger os dados dos usuário;
-Comunidade de usuários do Salesforce é extensa e ativa;
-Como uma plataforma baseada em nuvem, o Salesforce fornece atualizações regulares e automáticas;
   
Desvantagens: 
-Os custos podem ser mais altos em comparação com algumas soluções concorrentes; 
-Embora o Salesforce ofereça ferramentas sem código ele possui uma alta curva de aprendizado;
-Edições mais acessíveis do Salesforce podem ter limitações significativas em termos de personalização;
-Integração do Salesforce com sistemas legados pode ser complicado, especialmente se o sistema em questão usa tecnologias mais antigas;

b) Tipos de serviços oferecidos:

   Salesforce oferece uma variedade de serviços, incluindo CRM, automação de marketing, automação de vendas, atendimento ao cliente, Salesforce Einstein, que é a IA da empresa. Com esse software, gestores e desenvolvedores podem criar um assistente inteligente de forma personalizada para atender às suas necessidades. 

Em termos de infraestrutura, a Salesforce utiliza tecnologias em nuvem, mas a ênfase está mais nos serviços de aplicativos do que em serviços de infraestrutura como VMs ou containers.

c) Localização dos servidores:

   A Salesforce utiliza data centers distribuídos globalmente para fornecer seus serviços em nuvem. Locais em regiões metropolitanas :

-Chicago, Illinois, United States (USA)
-Dallas, Texas, United States (USA)
-Frankfurt, Germany (DE)
-Kobe, Japan (JPN)
-London, United Kingdom (UK)
-London North
-London West
-Paris, France (FRA)
-Phoenix, Arizona, United States (USA)
-Tokyo, Japan (JPN)
-Washington DC, United States (USA):
-Washington DC North
-Washington DC South
 
d) Custo:

   Em geral os custos podem ser considerados mais altos em comparação com algumas soluções concorrentes. Em contra partida eles possuem vários tipo de serviços, baseada em licenças de usuário e funcionalidades adicionais, podendo escolher em um plano que melhor se encaixe.

<img src="./img/preco0.png"/>

As formas de pagamento podem variar de acordo com o foco que o serviço vai tomar. Por exemplo: 

<img src="./img/preco.png"/>

<img src="./img/preco1.png"/>

e) Que empresas utilizam/contratam os serviços deste provedor:

    Alelo, ContaAzul, Globo, SulAmérica, Vipal Borrachas, Grupo Tigre, Gympass, Sumup, entre outros.


f) Tipos de Segurança - SLA:

   -A Salesforce adota medidas de segurança robustas, incluindo criptografia de dados com o Shield Plataform Encryption, controle de acesso, monitoramento de atividades, entre outros.

g) Qual você contrataria? Justifique a sua escolha:

   Pessoalmente eu escolheria a Google Cloud ou a Salesforce. Google Cloud por possuir uma variedade de soluções. Já a Salesforce por ser um sistema com que eu já trabalhei, porém seus altos preços me deixam com um pé atrás.
