Print das VMS



<img src="./img/vms1.png"/>
<img src="./img/vms2.png"/>
