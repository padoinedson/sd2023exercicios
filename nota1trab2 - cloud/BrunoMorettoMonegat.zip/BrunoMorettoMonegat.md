# Cloud Service 
## Comparativo de Provedores
### *Oracle Cloud:*
https://www.oracle.com/br/cloud/
#### Vantagens:
* Em questão de análises e BI, possui uma plataforma de analytics que permite que líderes, analistas e o TI acessem dados de onde quer que estejam, incluindo dispositivos móveis. Esses dados são organizados de forma que seja possível usá-los facilmente para melhorar a eficiência, reduzir custos e garantir a satisfação do cliente.
* Fornece serviços para análise e processamento de Big Data, como Hadoop, Hive, Spark e Hbase. Grandes quantidades de dados podem ser extraídos facilmente para o uso em análise de dados.
* Possui uma plataforma de transmissão de eventos Publish-Subscribe em tempo real, utilizando o Apache Kafka em tempo real, sem servidor. 
* Permite a criação de máquinas virtuais baseadas em processadores com a arquitetura Arm para maior custo-benefício.
* Pode ser considerado um dos provedores mais baratos quando levado em questão o custo-benefício. A seguir estão alguns exemplos de custos mensais de operação:
	* Uma instância de uma máquina virtual (AMD, 4 vCPUs, 16 GB RAM): **$54**, 34% mais barato do que na AWS.
	* Cluster Kubernetes (100 vCPUs, 750 GB RAM): **$1,734**, 42% mais barato do que na AWS.
	* Block Storage (1x1 TB, 15K IOPS, 125 MB/sec): **$522**, 3X mais barato do que na AWS.
	* Largura de banda pública transferível (50 TB): **$340**, 13X mais barato do que na AWS.
* Possui um serviço integrado que facilita a criação de contêineres Kuberenetes de alto desempenho gerenciados. Isso possibilita a execução de contêineres de forma descomplicada e rápida sem administrar qualquer infraestrutura.
* Possui também diversos serviços para auxiliar na criação e no gerenciamento de bancos de dados.
* Apresenta diversos serviços no que tange a segurança, como monitores de vulnerabilidade, gerenciadores de certificados SSL/TLS, além de um firewall para a rede e para aplicações web.
* Permite a criação de uma conta Always-Free vitalícia, garantindo uma máquina virtual com um processador ARM de 4 núcleos, além de 18GB de RAM.
* Usado por empresas como: Toyota, Zoom, FedEx e Tim.
#### Desvantagens:
* Possui apenas dois datacenters no Brasil. Ambos ficam no Sudeste, sendo um na cidade de São Paulo e outro na cidade de Vinhedo.
* Os únicos processadores viáveis para serem utilizados na versão Always-Free são baseados em ARM, o que pode não ser ideal para certas aplicações. Há como usar um processador AMD, porém ele será muito mais limitado quanto a sua disponibilidade e tempo de uso em comparação com os processadores ARM.
* Possui poucas opções quanto a customização das configurações das máquinas.
* Pelo menos de acordo com as informações presentes no site da Oracle, não há um número muito grande de empresas de tamanho significativo que estão usando a Oracle Cloud.
### *Amazon Cloud:*
https://aws.amazon.com/pt/
#### Vantagens:
* A abordagem de pagamento pay-as-you-go garante que o usuário só pagará pelos serviços que estiver realmente utilizando.
* Tem uma visão centrada na escalabilidade sob demanda. O Amazon EC2 possui mais de 700 instâncias e opções de processadores, armazenamentos, redes e sistemas operacionais. Esse serviço fornece escalonagem automática, adaptando os recursos de acordo com a demanda.
* Possui amplo suporte para processadores Intel, AMD e Arm.
* Graças a sua rede global de datacenters, é possível utilizar o serviço do Amazon CloudFront para aumentar drasticamente a performance e diminuir a latência de entrega de conteúdo de qualquer parte do mundo para qualquer parte do mundo.
* Apesar de ter apenas um datacenter na América do Sul, possui diversos locais de borda em diferentes países. Esses locais de borda fazem cache do conteúdo da rede de maneira eficiente, buscando priorizar uma entrega mais rápida ao estarem próximos do destinatário.
* Possui alguns serviços para gerenciamento de bancos de dados, como o Amazon S3, que também funciona na mentalidade pay-as-you-go.
* Em questão de segurança, a AWS fornece vários serviços, como o IAM, para autenticação de acesso e de identidade, o KMS, para o gerenciamento de chaves criptografadas, e o AWS Config, que apresenta uma visão mais geral sobre a segurança do sistema além de possuir diversos SLAs.
* A partir do ECR, do ECS, e do EKS é possível criar contêineres Kubernetes de maneira fácil, segura e escalável, sendo possível armazenar imagens de contêineres e executá-los de uma maneira serverless.
* Usado por empresas como: Airbnb, Netflix, McDonald's, Twitch, Adobe e Facebook.
#### Desvantagens:
* A conta Always-Free é muito limitada, fornecendo apenas alguns serviços básicos de armazenamento, gerenciamento e transferência de dados e requisições. 
* Não permite a criação de uma VM em uma conta Always-Free.
* O seu modelo de cobrança variável durante o escalonamento automático, chamado de pay-as-you-go, pode ser perigoso se não usado com cautela. Durante situações de alta demanda, como dias de Black Friday, por exemplo, podem aumentar muito o uso de recursos graças à necessidade de se fazer replicação de instâncias, aumentando os custos operacionais.
* Possui apenas um datacenter na América do Sul, que fica na cidade de São Paulo.
* A imensa variedade de serviços disponibilizados pela Amazon pode dificultar o aprendizado inicial do AWS, bem como a sua especialização, algo que já pode ser observado de início na nomenclatura distinta entre os produtos.
* É um dos provedores de cloud mais caros a longo prazo.
### *IBM Cloud:*
#### Vantagens:
* Possui um serviço próprio e robusto de TTS em larga escala. Ele utiliza o IBM Watson como inteligência artificial para converter voz para texto e vice-versa.
* A operação dos servidores é muito confiável, graças ao IBM Cloud Load Balancer, que equilibra o uso de recursos em diferentes máquinas, e aos datacenters redundantes.
* Usa o conceito de MZR, ou Regiões Multi-Zona, para a organização de interconexões entre os datacenters globais. Essas MZRs são como datacenters só que em uma menor escala. Nelas existem três equipamentos separados, todos com hardware de servidor de latência baixa, para que seja garantida a redundância física na região.
* Fornece acesso ao IBM Watson, que é um poderoso conjunto de serviços na área de inteligência artificial e aprendizado de máquina. É possível utilizá-lo para, por exemplo, criar chatbots automatizados no contexto de uma aplicação e integrá-los dentro dela facilmente.
* Oferece um sistema de pagamento similar ao da AWS, o pay-as-you-go, porém com um custo operacional relativamente menor.
* Possui diversos serviços na área de segurança, oferecendo uma variedade muito grande de soluções como firewalls, segurança para contêineres e autenticadores de identidade.
* Há uma calculadora de custos no site que permite fazer uma estimativa prévia dos custos operacionais.
* Usado por empresas como: Red Hat, Honeywell, Panasonic e Japan Airlines.
#### Desvantagens:
* Não há nenhum datacenter na América Latina, tendo apenas um MZR na cidade de São Paulo.
* Não apresenta muitos serviços quanto a criação e gerenciamento de contêineres, tendo apenas alguns serviços básicos para Kubernetes.
* Possui muitos serviços redundantes e específicos, que raramente teriam utilidade concreta na maioria das aplicações mais comuns usando um servidor cloud. Um exemplo disso seria os serviços de aprendizado de máquina do IBM Watson. 
* Os custos de transferências de dados entre regiões diferentes podem se tornar caros.
## Qual Eu Escolheria?
Para um servidor cloud pessoal, eu escolheria o Oracle Cloud, visto que ele possui os melhores recursos e serviços para o modelo Always-Free. A principal vantagem é a possibilidade de se criar uma VM em cloud com poder de hardware que vai além do necessário para a maioria das aplicações privadas, sendo possível usá-la como servidor cloud para diversos serviços simultaneamente de maneira permanente. 
Já para um servidor destinado a aplicações maiores e mais complexas, onde há recursos disponíveis para se investir em um serviço mais escalável e resiliente, eu escolheria a AWS, visto que ela é a mais reconhecida e utilizada no mercado de provedores cloud, o que garante que ela é uma opção mais confiável em cenários de produção. Além disso, ela oferece uma gama muito maior de serviços na sua versão paga, os quais podem vir a ser úteis no contexto de uma aplicação empresarial distribuída.