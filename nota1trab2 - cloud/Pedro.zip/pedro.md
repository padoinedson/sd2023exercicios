# EXERCÍCIOS CLOUD
## DIGITAL OCEAN
a) Vantagens e desvantagens sobre outras empresas:
Vantagens da DigitalOcean:
Facilidade de Uso: Possui uma interface de usuário simples e fácil de usar, facilitando a
implementação e gerenciamento de servidores.
Preços Transparentes: um diferencial da empresa é sua estrutura de preços transparente e preços
acessíveis, com opções de pagamento por hora ou por mês.
Droplets: Os servidores virtuais da DigitalOcean, chamados de Droplets, são fáceis de implantar e
escalonar. Eles oferecem uma variedade de tamanhos para atender às necessidades específicas de
recursos.
Comunidade Ativa: Tem uma comunidade ativa e recursos de suporte que podem ser úteis para
desenvolvedores que buscam assistência e soluções para problemas comuns.
Desvantagens da DigitalOcean:
Menos Recursos: Quando comparada a algumas das maiores provedoras de nuvem, como AWS,
Azure e Google Cloud, a DigitalOcean pode ter uma presença de data center menos extensa em todo
o mundo, o que pode afetar o desempenho em algumas regiões geográficas.
Menos Serviços Gerenciados: Enquanto ela oferece uma variedade de serviços, ela pode ter menos
opções de serviços gerenciados em comparação com outras nuvens. Isso significa que, em alguns
casos, mais trabalho de gerenciamento pode recair sobre o usuário.
b) Tipos de serviços oferecidos: Escalabilidade, VM, Container (docker)
A DigitalOcean oferece diversos serviços, e abaixo listei alguns tipos que podem ser utilizados para
diferentes finalidades, incluindo escalabilidade, máquinas virtuais (VMs) e containers (Docker):
Droplets (VMs): Os Droplets são máquinas virtuais da DigitalOcean. Eles podem ser facilmente
provisionados e escalados para atender às necessidades específicas de recursos do seu aplicativo.
Os Droplets oferecem uma variedade de tamanhos e configurações para atender a diferentes cargas
de trabalho.
Kubernetes: serviço gerenciado de Kubernetes (DOKS), que permite a orquestração de contêineres
usando Kubernetes. Isso facilita a implantação e o gerenciamento de aplicativos em contêineres,
proporcionando escalabilidade e flexibilidade.
Spaces e Volumes: Spaces é um serviço de armazenamento de objetos da DigitalOcean,
semelhante ao Amazon S3. Ele permite armazenar e servir grandes quantidades de dados, como
imagens, vídeos e backups. Os Volumes, por outro lado, são discos adicionais que podem ser
anexados aos Droplets para armazenamento persistente.
Databases: A DigitalOcean oferece serviços de banco de dados gerenciados para diversos tipos de
bancos de dados, incluindo PostgreSQL, MySQL e Redis.
c) Localização dos servidores
A DigitalOcean possui data centers distribuídos em várias regiões geográficas ao redor do mundo
para fornecer serviços de nuvem com baixa latência e alta disponibilidade. Algumas das regiões que
possuem servidores são:
América do Norte
- Nova York
- San Francisco
- Toronto
Europa
- Londres
- Frankfurt
- Amsterdã
Ásia-Pacífico
- Singapura
- Banguecoque
- Bangalore
d) Custo
Os custos associados ao uso dos serviços da DigitalOcean podem variar dependendo dos recursos
específicos que você escolher, da região do data center em que você hospeda seus serviços e de
como você utiliza esses recursos. Os usuários geralmente pagam por recursos consumidos com
base em uma estrutura de preços por hora ou por mês.
A DigitalOcean oferece uma calculadora de preços em seu site que permite estimar os custos com
base nos recursos que você planeja utilizar. Recomendo usar essa calculadora e revisar a página de
preços oficial da DigitalOcean para obter informações detalhadas e atualizadas sobre os custos
associados aos serviços específicos que você pretende usar.
e) Que empresas utilizam/contratam os serviços deste provedor
A DigitalOcean é uma provedora popular de serviços em nuvem, e muitas empresas, especialmente
startups, desenvolvedores independentes e pequenas e médias empresas, utilizam seus serviços
para hospedar aplicativos, sites e outros recursos na nuvem. Encontrei algumas empresas que
utilizam ou já utilizaram seus serviços.
Slack: Embora a Slack também utilize outras provedoras de nuvem, como AWS, é conhecido que
eles têm uma presença na DigitalOcean para algumas de suas operações.
Mozilla: Organização por trás do navegador Firefox, já utilizou a DigitalOcean para hospedar alguns
de seus projetos e serviços.
HashiCorp: Empresa conhecida por ferramentas populares como Terraform e Consul, é uma usuária
da DigitalOcean para alguns de seus serviços.
As escolhas de provedores de nuvem podem variar dependendo das necessidades específicas de
uma empresa, e muitas organizações usam uma combinação de provedores de nuvem para atender
a diferentes requisitos.
f) Tipos de Segurança - SLA
Disponibilidade: Assim como muitos provedores de serviços em nuvem, a DigitalOcean estabelece
compromissos de disponibilidade em seus SLAs. Isso especifica o tempo de atividade esperado para
os serviços oferecidos.
Segurança Física: Compromissos relacionados à segurança física dos data centers, incluindo
controle de acesso, vigilância por vídeo e medidas para prevenção de incêndios e outros desastres
físicos.
Backup e Recuperação: A definição da frequência de backup, a política de retenção de dados e os
procedimentos de recuperação em caso de falhas.
Isolamento de Recursos: A garantia de que os recursos de diferentes clientes são isolados
adequadamente para evitar vazamento de dados ou interferência entre usuários.
g) Qual você contrataria? Justifique a sua escolha
Por ter mais experiência com o serviço e já ter trabalhado em aula, utilizaria a AWS.
É uma das provedoras de serviços em nuvem mais utilizada e é escolhida por muitas empresas e
desenvolvedores em todo o mundo. oferece uma ampla gama de serviços, incluindo computação,
armazenamento, banco de dados, machine learning, analytics, segurança e muito mais.
A AWS é projetada para fornecer escalabilidade elástica, permitindo que os usuários dimensionem
seus recursos para cima ou para baixo de acordo com a demanda. Isso é crucial para empresas com
necessidades dinâmicas de capacidade, além de oferecer uma variedade de recursos e práticas de
segurança, incluindo criptografia, monitoramento, controle de acesso e conformidade com padrões
de segurança reconhecidos. Isso é crucial para proteger dados sensíveis.
PEDRO HENRIQUE VON GROLL