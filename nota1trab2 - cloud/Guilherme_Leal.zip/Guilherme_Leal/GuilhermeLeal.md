Guilherme Leal
Google Cloud

a) Vantagens e desvantagens sobre outras empresas

O Google Cloud possui a maior rede de data centers em todo o mundo, permitindo uma alta distribuição geográfica e baixa latência. Ele possui uma estrutura de preço transparente e competitiva. O serviço investe muito em segurança, disponibilizando diversas ferramentas para seus clientes. Existe também uma comunidade muito ativa e colaborativa, assim como uma documentação abrangente sobre todos os diversos serviços da plataforma. Além disso, esse sistema é integrado com todos outros produtos da Google, como o G Suite, Workspace ou Analytics, isso permite um uso em conjunto desses sistemas de forma mais direta e eficaz.

b) Tipos de serviços oferecidos: Escalabilidade, VM, Container (docker)

O Google Cloud oferece diversos serviços, dos mais diversos tipos. Alguns dos mais utilizados de computação em cloud são o Google Compute Engine, que oferece serviços de VMs, e o Google Kubernetes Engine, esse é utilizado no gerenciamento de contêineres. Porém existem muitos outros serviços, entre eles estão o Google Cloud Storage, Cloud SQL, Cloud Spanner, Virtual Private Cloud, Cloud Load Balancing, BigQuery, AI Platform, Natural Language AI, Identity and Access Management, Cloud Build, Cloud Trace e Cloud Profiler e muitos outros.

c) Localização dos servidores

Eles se localizam em diversos continentes, sendo eles América do Norte, América do Sul, Europa, Ásia, Oceania e África.

d) Custo

Existem diferentes formas de se calcular o custo dos serviços do Google Cloud. Alguns serviços têm os custos calculados de acordo com a quantia de recursos consumidos, em outros é possível alugar máquinas e pagar apenas o aluguel, enquanto alguns serviços são cobrados por tempo de uso. Além disso, existem outros fatores que podem influenciar o custo, como o tráfego de rede, região e zona dos recursos utilizados, licenciamento de software, armazenamento, entre outros.

e) Que empresas utilizam/contratam os serviços deste provedor

Natura, Magazine Luiza, Mercado Livre, SBT, Globo, PayPal, X, Spotify, Philips, Sony, Niantic, Ebay, FIFA, Epic Games, Walmart, Coca-Cola, Nestlé, Subaru, AT&T, The New York Times, UPS, King, 20th Century Fox, LATAM Airlines, entre outros.

f) Tipos de Segurança - SLA

O Google Cloud possui diversos tipos de segurança diferentes. É utilizada uma rede de segurança contra ataques de DDoS, assim como Virtual Private Cloud, onde é possível que clientes isolem suas redes. Existem serviços como o IAM e Cloud Identity, onde é possível gerenciar acessos a rede e serviços. Também existem proteções contra ataques comuns em redes como SQL injection e XSS por meio do Cloud Armor. Além disso existem vários outros serviços de proteção digital e dos servidores físicos.

g) Qual você contrataria? Justifique a sua escolha

Em questão de empresas, provavelmente eu contrataria os serviços da Google, devido aos seus preços competitivos e diversidade de soluções comparados a competição.
