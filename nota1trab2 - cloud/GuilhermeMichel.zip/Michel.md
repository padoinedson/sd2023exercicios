	**Jelastic**

	a) Vantagens e desvantagens sobre outras empresas

Vantagens sobre outras empresas: Escalabilidade Automática(recursos podem ser dimensionados automaticamente conforme a demanda), Suporte a Múltiplos Idiomas e Stacks(Suporta várias linguagens de programação e stacks), Modelo de Preços Flexível(usuários pagam apenas pelos recursos que consomem), Gerenciamento Simplificado(facil implementação e o gerenciamento de aplicativos), Compatibilidade com Diversos Provedores de Nuvem(permite aos usuários escolherem a infraestrutura de nuvem que melhor atenda às suas necessidades)


Desvantagens sobre outras empresas: Curva de Aprendizado(Tem uma certa uma curva de aprendizado para usuários iniciantes que talvez demande as configurações específicas), Customização Limitada(Jelastic pode oferecer menos opções de personalização em comparação com demais), Dependência do Fornecedor(os usuários podem ficar um pouco dependentes da Jelastic e seus recursos específicos), Foco Específico em PaaS(por ser uma plataforma PaaS específica pode não ser a escolha ideal para todas as aplicações)

	b) Tipos de servicos oferecidos: Escalabilidade, VM, Container (docker)

Ela possui compatibilidade em oferecer esses servicos. Como mencionado nas vantagens ela possui uma escabilidade automática permitindo que recursos da aplicação tem a possibilidade de serem dimensionados automaticamente com base na demanda, a Jelastic suporta a execução de máquinas virtuais e também é conhecida por sua forte integração com contêineres Docker.

	c) Localização dos servidores

Sendo uma de suas vantagens ter suporte a diversos provedores, a localização dos servidores pode depender do provedor escolhido pelo usuário, sendo que a plataforma é projetada para ser compatível com vários provedores de nuvem, permite que os usuários escolham a infraestrutura que melhor atenda às suas necessidades. Alguns dos provedores de nuvem parceiros da Jelastic incluem Amazon Web Services (AWS), Microsoft Azure, Google Cloud Platform (GCP), DigitalOcean, Vultr...

	d) Custo

Os custos associados ao uso da Jelastic podem variar dependendo de vários fatores, incluindo o provedor de nuvem escolhido, a quantidade de recursos consumidos (como CPU, RAM, armazenamento), o tráfego de rede, entre outros. Possuindo um modelo de preço flexível, o usuário, só paga pelos recursos que consomem.

	e) Que empresas utilizam/contratam os serviços deste provedor

Jelastic é utilizado por integradores de sistemas e empresas de diversas esferas (finanças, software, esportes, jogos etc.) como International Football Association Board , GMV , G5 Games, Miele, Philips Lighting e outras

	f) Tipos de Segurança - SLA

SLA da Jelastic se resume em:  Segurança da Rede(Proteção da infraestrutura de rede, como firewalls, controles de acesso e monitoramento de tráfego), Segurança Física(data centers, como controle de acesso físico, monitoramento por vídeo, segurança contra incêndios e redundância de energia), Segurança de Dados(criptografia, controles de acesso e conformidade com regulamentações de privacidade), Resiliência e Recuperação de Desastres(procedimentos para minimizar o impacto de falhas e garantir a continuidade dos serviços), Monitoramento e Resposta a Incidentes(pode incluir prazos para notificação de incidentes e ações corretivas), Conformidade e Governança(informações sobre auditorias regulares), Disponibilidade e Tempo de Inatividade Planejado(Isso pode ser expresso como uma porcentagem de tempo de operação contínua (uptime) e pode incluir compensações por violações de SLA), Backup e Recuperação de Dados(Detalhes sobre os procedimentos de backup, retenção de dados e capacidade de recuperação para garantir a integridade dos dados do cliente)

	g) Qual você contrataria? Justifique a sua escolha

Eu escolheria a AWS levando em consideração a experiência, pois ja realizei trabalhos referentes a ela e também ser bastante recomendada para utilização em empresas.
