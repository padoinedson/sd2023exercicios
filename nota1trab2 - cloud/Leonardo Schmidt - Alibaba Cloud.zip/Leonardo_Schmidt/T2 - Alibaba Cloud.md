﻿# Trabalho 2: Análise do Provedor de Serviços em Nuvem - Alibaba Cloud

## Leonardo Ojczenasz Schmidt  
## Provedor: Alibaba Cloud

**a) Vantagens e desvantagens sobre outras empresas**

Vantagens:

- Bom custo-benefício: A Alibaba Cloud se destaca por oferecer uma equação atrativa entre custo e benefício, tornando-se uma escolha econômica para diversas empresas.
- Alta disponibilidade dos serviços: A infraestrutura robusta garante uma alta disponibilidade de serviços, minimizando possíveis períodos de inatividade e garantindo operações contínuas.
- Certificado SSL Gratuito: O fornecimento de certificados SSL gratuitos não apenas aprimora a segurança das comunicações online, mas também reflete um compromisso com as melhores práticas de segurança.
- Infraestrutura robusta: A Alibaba Cloud possui uma infraestrutura tecnologicamente avançada, proporcionando um ambiente confiável e eficiente para os usuários.
- Hardware com tecnologia de ponta: A utilização de hardware de última geração posiciona a Alibaba Cloud na vanguarda da inovação tecnológica, potencialmente traduzindo-se em melhor desempenho para os usuários.

Desvantagens:

- Suporte por chat somente em inglês: A limitação do suporte a chat apenas em inglês pode representar um desafio para usuários que preferem ou necessitam de suporte em outros idiomas.
- Não oferece atendimento telefônico no Brasil: A ausência de suporte telefônico local pode impactar a experiência do cliente, especialmente para usuários no Brasil.
- Pagamento em dólar: O requisito de pagamento em dólar pode resultar em complexidades financeiras, sujeitas a flutuações cambiais e custos adicionais para usuários brasileiros.

**b) Tipos de serviços oferecidos: Escalabilidade, VM, Container (docker):**

Escalabilidade: A Alibaba Cloud oferece serviços escaláveis, permitindo aos usuários ajustar recursos conforme suas necessidades evoluem.

VM (Máquinas Virtuais): Disponibiliza Máquinas Virtuais que possibilitam a execução de diferentes sistemas operacionais em um único servidor físico.

Container (Docker): Suporta tecnologias de contêiner, como Docker, facilitando o desenvolvimento e implantação eficiente de aplicativos.

**c) Localização dos servidores**

Os servidores da Alibaba Cloud estão distribuídos globalmente.

![Localizacao dos Servidores](images/localizacaoservidores.png)
![Localizacao dos Servidores detalhada](images/localizacaoservidores1.png)

**d) Custo:**

Os custos variam conforme os serviços, o foco e a região do servidor. Precisaria que o usuário realize uma análise detalhada da estrutura de preços para uma escolha correta.

![Custo](images/custo.png)
![Custo pós-venda](images/custo1.png)

**e) Que empresas utilizam/contratam os serviços deste provedor**

Pelo que pude encontrar, a Alibaba Cloud atende a uma grande variedade de empresas, desde startups até grandes corporações, como as empresas Aliexpress, Taobao, Tmall, Ant Financial e Alimama.

**f) Tipos de Segurança - SLA**

O SLA da Alibaba Cloud para o Elastic Compute Service (ECS) é uma estrutura crucial que define os padrões de desempenho e disponibilidade dos serviços oferecidos. Destacando pontos essenciais:

- Definições Importantes:
  - Métricas como Monthly Service Fee, Instance Service Cycle, Instance Unavailable, etc., fornecem uma base para avaliação.
- Exclusões:
  - O SLA não se aplica a eventos fora do controle razoável, ações do usuário, eventos ilegais, entre outros, listados como Exclusões.
- Garantia de Serviço:
  - Compromisso de garantir uma porcentagem mínima de disponibilidade mensal para instâncias ECS individuais e em várias zonas.
- Processo de Reivindicação e Pagamento:
  - Procedimentos detalhados para apresentação de reclamações, incluindo prazos e informações necessárias.
  - Avaliação pela Alibaba Cloud e determinação de créditos de serviço com base na porcentagem de disponibilidade perdida.
- Termos Adicionais:
  - Registros da Alibaba Cloud prevalecem em caso de inconsistência.
  - Créditos de serviço são o único recurso para falhas de desempenho; a Alibaba Cloud não se responsabiliza por danos indiretos ou consequentes.
- Alterações no SLA:
  - A Alibaba Cloud reserva-se o direito de alterar os termos do SLA, com as alterações refletidas no site internacional.


**g) Qual você contrataria? Justifique a sua escolha:**

A escolha da Alibaba Cloud é respaldada por sua proposta de custo-benefício atrativa, garantindo alta disponibilidade e oferecendo certificados SSL gratuitos para reforçar a segurança. A infraestrutura tecnologicamente avançada e o uso de hardware de ponta destacam a inovação da Alibaba Cloud. Embora o suporte por chat seja limitado ao inglês e não haja atendimento telefônico local no Brasil, as amplas opções de escalabilidade, máquinas virtuais e suporte a contêineres, como Docker, contribuem para sua versatilidade. Atendendo desde startups até grandes corporações como Aliexpress e Taobao, a Alibaba Cloud se destaca como uma escolha sólida. A transparência do SLA reforça seu compromisso com o desempenho, embora seja crucial monitorar possíveis alterações nas políticas.