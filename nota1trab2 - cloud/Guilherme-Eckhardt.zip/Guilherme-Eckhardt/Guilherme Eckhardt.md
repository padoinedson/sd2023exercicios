a) Vantagens e desvantagens sobre outras empresas:
    Vantagens:
        Marca reconhecida: A UOL é uma das maiores empresas de internet do Brasil, o que pode inspirar confiança.
        Variedade de serviços: Oferece uma ampla gama de serviços, desde hospedagem compartilhada até soluções mais avançadas.
        Suporte técnico: Geralmente, empresas estabelecidas têm suporte técnico mais robusto.

    Desvantagens:
        Custo: Pode ser mais caro em comparação com algumas empresas menores.
        Complexidade: Para usuários que precisam de soluções simples, a variedade de serviços pode parecer excessiva.

b) Tipos de serviços oferecidos:
    Escalabilidade: A UOL Host oferece planos escaláveis que podem atender desde pequenos sites até grandes aplicações.
    VM (Máquinas Virtuais): Oferece serviços de hospedagem VPS (Virtual Private Server).
    Container (Docker): Pode oferecer soluções que suportam containers Docker, dependendo do plano escolhido.

c) Localização dos servidores:
    A UOL Host possui data centers no Brasil, o que pode ser uma vantagem para empresas que visam um público brasileiro.

d) Custo:
    Os custos podem variar dependendo do plano escolhido. Em geral, a UOL Host pode ser um pouco mais cara do que algumas alternativas, mas oferece uma variedade de serviços.

e) Que empresas utilizam/contratam os serviços deste provedor:
    A UOL Host atende a uma ampla gama de clientes, desde pequenas empresas até grandes corporações, em setores diversos.

f) Tipos de Segurança - SLA:
    A UOL Host deve oferecer acordos de nível de serviço (SLAs) que detalham seus compromissos em termos de disponibilidade, suporte e segurança.

g) Qual você contrataria? Justifique a sua escolha:

    Devido à minha experiência e ao trabalho anterior, escolheria usar a Amazon Web Services (AWS). É uma das principais opções para serviços em nuvem, muito usada por empresas e desenvolvedores em todo o mundo. A AWS oferece muitos serviços, como computação, armazenamento, bancos de dados, aprendizado de máquina, análise e segurança.
    A AWS é feita para ser fácil de ajustar conforme a necessidade, o que é importante para empresas com demandas que mudam muito. Além disso, ela tem muitas medidas de segurança, como criptografia, monitoramento e controle de acesso, o que é crucial para proteger informações importantes.

