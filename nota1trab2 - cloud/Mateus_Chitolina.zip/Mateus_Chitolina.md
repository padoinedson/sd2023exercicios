## Vantagens e desvantagens sobre outras empresas
Vantagens: 
 - variabilidade de serviços disponibilizados pela Oracle Cloud. 
 - Interface amigável. 
 - Conectividade de alta velocidade e baixa latência entre os recursos

Desvantagens:
 - preços elevados em relação às demais empresas.

## Tipos de serviços oferecidos: Escalabilidade, VM, Container (docker)
- Computação: fornece instâncias de máquinas virtuais para fornecer diferentes formatos (tamanhos de VM) atendendo a diferentes tipos de cargas de trabalho e características de desempenho.
- Armazenamento: fornece volumes em blocos, armazenamento de arquivos, armazenamento de objetos e armazenamento de arquivos para banco de dados, análises, conteúdo e outros aplicativos em protocolos e APIs comuns.
- Rede: fornece à rede de endereços IP, sub-redes, roteamento e firewalls totalmente configuráveis ​​para oferecer suporte a redes privadas novas ou existentes com segurança de ponta a ponta.
- Governança: verificações de integridade de dados, rastreabilidade e recursos de gerenciamento de acesso.
- Gerenciamento de banco de dados/gerenciamento de dados: oferece uma plataforma de gerenciamento de dados para cargas de trabalho de banco de dados, bem como big data em hiperescala e cargas de trabalho de streaming, incluindo OLTP, armazenamento de dados, Spark , aprendizado de máquina , pesquisa de texto, análise de imagens, catálogo de dados e aprendizado profundo .
- Balanceamento de carga: oferece capacidade de balanceamento de carga para rotear automaticamente o tráfego entre domínios de falha e domínios de disponibilidade para alta disponibilidade e tolerância a falhas para aplicativos hospedados.
- Serviços Edge: esses serviços podem monitorar o caminho entre usuários e recursos e se adaptar a mudanças e interrupções usando infraestrutura DNS segura.
- FastConnect: fornece conectividade privada em redes locais e em nuvem por meio de provedores como Equinix , AT&T e Colt .
- Desenvolvimento de aplicativos: oferece uma plataforma de desenvolvimento de aplicativos aberta e baseada em padrões para construir, implantar e gerenciar aplicativos em nuvem com prioridade para API e dispositivos móveis. Esta plataforma oferece suporte ao desenvolvimento nativo de contêiner, nativo de nuvem e de baixo código.
- Integração: oferece adaptadores para integrar aplicativos locais e em nuvem. Os recursos incluem integração e replicação de dados, gerenciamento de API, análise de integração, juntamente com migração e integração de dados. Eles oferecem serviços como nuvem de plataforma de integração de dados, serviço de nuvem integrador de dados, serviço de nuvem GoldenGate, nuvem de integração, serviço de nuvem de processo, serviço de nuvem de plataforma API, serviço de nuvem de apiário e serviço de nuvem SOA.
- Análise de negócios: incluem nuvem analítica, inteligência de negócios, descoberta de big data, preparação de big data, visualização de dados e essa base.
- Segurança: oferece um SOC (Centro de Operações de Segurança) de identidade por meio de uma oferta combinada de SIEM, UEBA, CASB,l e IDaaS. Os serviços oferecidos incluem Identity Cloud Service e CASB Cloud Service.
- Gestão: monitoramento de desempenho de aplicativos, monitoramento de infraestrutura, análise de log, orquestração, análise de TI, configuração e conformidade, monitoramento de segurança e análise.
- Conteúdo e experiência: esta é uma plataforma para gerenciamento de conteúdo, site e fluxo de trabalho. Este serviço é usado para fornecer colaboração de conteúdo e presença na web. Esta ferramenta vem integrada aos serviços locais e SaaS da Oracle.

## Localização dos servidores
A disponibilização dos servidos da OCI depende dos servidores que estão localizados pelo mundo.
 - Database Service for Microsoft Azure: Ashburn, Phoenix, San Jose, Toronto, Vinhedo, Frankfurt, Amsterdã, Londres, Joanesburgo, Tóquio, Seul, Singapura.
 - Interconnect for Microsoft Azure: Ashburn, Phoenix, San Jose, Toronto, Vinhedo, Frankfurt, Amsterdã, Londres, Joanesburgo, Tóquio, Seul, Singapura.
 - Computação Confidencial: Ashburn, Phoenix, Toronto, Frankfurt, Zurique, Londres, Gov do Reino Unido Newport, Sydney.
 - Serviço Data Transfer: Ashburn, Phoenix, Frankfurt, Londres, Osaka, Tóquio, Seul.
 - Roving Edge Infrastructure: Ashburn, Governo dos EUA Ashburn, Frankfurt.
 - Access Governance: Ashburn, São Paulo, Frankfurt, Abu Dhabi, Sydney.
 - Plataforma de cadeia de blocos: Ashburn, Chicago, Phoenix, San Jose, Montreal, Toronto, São Paulo, Santiago, Frankfurt, Milão, Amsterdã, Zurique, Londres Jeddah, Dubai, Sydney, Hyderabad, Mumbai, Osaka, Tóquio, Seul, Singapura.
 - Full Stack Disaster Recovery: Ashburn, Phoenix, San Jose, Montreal, Toronto, São Paulo, Vinhedo, Santiago, Frankfurt, Amsterdã, Londres, Jeddah, Dubai, Melbourne, Sydney, Hyderabad, Mumbai, Osaka, Tóquio, Singapura.

## Custo
O custo varia de acordo com os serviços que deseja contratar, o site oficial oferece como exemplo como US$4,25/mês por 100 GB e 6000 IOPS em para realizar o armazenamento em blocos. Para realizar uma conectividade privada com fastconnect de 10 GBps custa US$ 1,275/hora, já a saída de dados custa US$ 0,0085 por GB/hora e por fim o aluguel de VMs para fins gerais tem o custo de US$ 0,0980/hora. Claro que caso seja necessário basta fazer um orçamento com a plataforma solicitando mais recursos que vai resultar em um valor diferente.

## Que empresas utilizam/contratam os serviços deste provedor
Algumas das empresas que contratam os serviços da Oracle Cloud Infrastructure são o Uber, ZOOM, FedEx, Toyota, TIM, Mazda.

## Tipos de Segurança - SLA
Os pilares da segurança que compõem o OCI consiste no isolamento do cliente que consiste em isolar a aplicação e dados do cliente dos demais serviços. Também é comumente utilizado a criptografia de dados o controles de segurança através de credenciais de acesso, monitorar a visibilidade dos seus dados, além de possuir uma infraestrutura segura possuindo conformidade com um grande intervalo de padrões e requisitos incluindo FedRAMP, FIPS 140-2, GDPR, HIPAA, PCI DSS e SOC 1/2/3.

## Qual você contrataria? Justifique a sua escolha
Por mais que a quantidade de serviços seja vantajosa e a velocidade de conexão seja boa o custo que este serviço cobra em cima de funcionalidade que eu provavelmente utilizaria não vale a pena em comparação com a Google Cloud e a AWS. Por conta disso e integrações que facilitariam algumas interações com o sistema eu escolheria a Google Cloud para contratar.
