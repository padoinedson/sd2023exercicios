## <<<<< INSTALAÇÃO NO HOST >>>>>
### arquivo instalacao.md  

## <<<<< INSTALAÇÃO EM CONTAINER >>>>>
### arquivo Dockerfile

![Container criado com Dockerfile](Dockerfile.png)

## <<<<< INSTALAÇÃO EM CONTAINER VIA COMPOSE >>>>>

### arquivo docker-compose.yml!

![Container criado com docker compose](docker-compose.png)


### Criado uma tabela sem entrar no container através do comando Docker exec
![Usando comando Docker exec para criar uma tabela no banco](docker-exec.png)

![Tabela criada](tabela-criada.png)
