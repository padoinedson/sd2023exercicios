
print('Hello World')
