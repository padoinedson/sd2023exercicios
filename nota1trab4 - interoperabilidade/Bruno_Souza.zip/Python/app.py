from flask import Flask, request, jsonify
from flask_cors import CORS
import firebase_admin
from firebase_admin import credentials, db

app = Flask(__name__)
CORS(app)

cred = credentials.Certificate({
  "type": "service_account",
  "project_id": "trabalho4-fb232",
  "private_key_id": "a9dc6d3ffc7b0cb5fc5ba9b643ca041b6191f38b",
  "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQDLoeLkRlhy6v7q\neOjGyJPaY40IIQ60iljxtxgcg4w3aNlYycuCTLZrJBoiGykelbxxRT0wp9p+m1MW\n1KD17nedyqZLiH5fiOf3PDobjrnsiQHndslr5s+THg2lxeP86g199lIRv7m782l4\n5ah1gDYRIHGDpJkM+ipc7/9R2eCcuhx8Tc6yZHLSeysn9xfRmoVRgX35P6KyxNxT\n5SVLXVSobQhn+Dt6FoM6s6xbpvqUSqORLcfwHsb71gZZkpDH/5K6XRZUsaGcnT1N\nLbn8/rYcbF78K/Mqofjdq5uNSo4TT2d2+ye80cTgL1rwDV8MsVo3Qvf0fUtlazuW\nQe+/LEzXAgMBAAECggEAVRpXplqF7aUrm1ejxSwfqrZPQzX5nNdy+7YvE/+gUqn1\nqAdSD6c618UzTMy4HymqI1ayD4sfJCmLDLAZgx7CDAadAFVPp2Kiu2+Gw2yfZG0Q\nCCnbXUaNuujlAEKXmWRB9kJDI1rS52t/yYCFqnHGZtr9xew88LD+km/U72LU3fql\nN8WEAVkofHa0jsQIOnxhMouRJsKJKEZ56rSzQT0vMVXj+khCLM+HjmZ9oXlX2RnD\nqUjBMAAdjAYAmL3HZk7fHLN6+k6OLB0do3oR7NeJhL99Yj2AMqklAdCr6qgfNdsj\nsHNzg9novkZDxwIAmGt56j8jmc78vCdZFUDTp5NtlQKBgQDpgGNxsgZ2VDWBBbc0\nLSogRGzxeqWfIeZM1LGrT+6p5q0RU5heQEhYsYZDSe4t4BkA5ksjAifj/T7lG5Pb\nU6XuE/zSYquPitvC9i0EoCDmpi0+Rvt33oN2gD+MLYJZROEq3YtHcBGdLdYa+N1I\nWIugYdvzTYTf4A1eMtNGBEUFIwKBgQDfQLzCJvGjB9pdaE1GD/du8fopUG/QiPOW\ntMP/2GzMXzKybngiFPfhqSNHQ0Jkrk8iuuuYDCfqAgLBYEGZ+Ejv0KGhKCZb2HVI\nGv2cZ0KhGsLznz/L8+XMALwCVR8xLOc7urIci6PmNlxQqSs0P8pQBKPONpJLH8lZ\nWh+1Q8eWvQKBgQC10ludNNsDWR8wkJrP7jtXVPDgOHivKV6DhTu0AlH9yroJO+bx\nvWyYY+QAkZj97/qIUMtBP3SAe7p1/Lttlf0nHjlIOb0N0Tq+3aLAb1AvSkcAr5Ux\nCfukUskpBmbxzEjpcAn8Xq/YjNCjwBXPN+PBx3HWSw6kpXrDVyBc7QYxsQKBgEZe\nUGDeB5H8mq6QfrLTu4kDyncVPHk9gZICHjlZTUnJw+AMA9+yPkOpnU4L/DRh4N2w\njyvYwQf4ZEfxgBv473xvhVKXpieS/byhjUisH4tKNSK3ElPF56u6m4gcrn1Aiw3/\nlb57oUih380o1U5dwPYh0EPiXZBCT6PTTWVEHPf9AoGBAJPbXXsj+9/7T5oeNnaR\nKf2YO0LWydQzcCqtBYPnBkanm6YEtC5usiSaq9BRY3lqQMQsM46NMn+hAhJvKxoq\n7dUyLXXrBN/uiNc837jxvgt8/GNKL00/nF2VyOB+Elv3uCtRYEYadHP+4rQKtuq9\n214UQcnO18D1G0mQOzx3OG4U\n-----END PRIVATE KEY-----\n",
  "client_email": "firebase-adminsdk-5270u@trabalho4-fb232.iam.gserviceaccount.com",
  "client_id": "104560094276926675022",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://oauth2.googleapis.com/token",
  "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
  "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-5270u%40trabalho4-fb232.iam.gserviceaccount.com",
  "universe_domain": "googleapis.com"
})

firebase_admin.initialize_app(cred, {'databaseURL': 'https://trabalho4-fb232-default-rtdb.firebaseio.com/'})
ref = db.reference('/dados')

# Rota para inicializar a base de dados
@app.route('/api/initDatabase', methods=['GET'])
def init_database():
    try:
        # Adicionar um dado à referência do Realtime Database para inicializar a base de dados
        ref.push({'init': True})

        response_data = {"status": "success", "message": "Database initialized successfully."}
        return jsonify(response_data)

    except Exception as e:
        response_data = {"status": "error", "message": str(e)}
        return jsonify(response_data)

# Rota para receber dados via POST e adicionar ao Realtime Database
@app.route('/api/data', methods=['POST'])
def receive_data():
    data = request.get_json()

    # Adicionar dados ao Realtime Database
    ref.push(data)

    # Responder com dados em JSON
    response_data = {"status": "success"}
    return jsonify(response_data)

if __name__ == '__main__':
    app.run(debug=True)