const axios = require('axios');

const pythonServerUrl = 'https://trabalho4-fb232-default-rtdb.firebaseio.com/dados/teste.json';  // Servidor Flask que vai ser enviado

const dataToSend = { key: 'value' };  // Envia um Dado para o Servidor

// Fazer uma solicitação POST para o servidor Python
axios.post(pythonServerUrl, dataToSend)
    .then(response => {
        console.log(response.data);
    })
    .catch(error => {
        console.error('Erro ao fazer a solicitação:', error);
    });
