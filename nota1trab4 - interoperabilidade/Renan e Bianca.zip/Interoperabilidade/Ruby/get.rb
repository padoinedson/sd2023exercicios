require 'firebase'

firebase = Firebase::Client.new("https://renan-sis-dis-default-rtdb.firebaseio.com/")  

response = firebase.get("261023")

if response.success?
   data = response.body
   # Converte o JSON em uma string formatada
   formatted_data = JSON.pretty_generate(data)
   # Divide a string em linhas e imprime cada linha
   formatted_data.split("\n").each { |line| puts line }
else
   puts "Erro de GET"
end
