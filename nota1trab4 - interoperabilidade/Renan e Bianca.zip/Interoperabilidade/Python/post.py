# -*- coding: utf-8 -*-

import requests
import json

# URL do Firebase Realtime Database
firebase_url = "https://renan-sis-dis-default-rtdb.firebaseio.com/261023.json"

Nome = raw_input("Digite o nome: ").strip()
Sobrenome = raw_input("Digite o sobrenome: ").strip()
UF = raw_input("Digite o estado onde mora: ").strip()

# Dados que você deseja enviar (no formato JSON)
data = {
    "Nome": Nome,
    "Sobrenome": Sobrenome,
    "UF": UF
}

# Converte os dados para JSON
data_json = json.dumps(data)

# Define o cabeçalho da solicitação
headers = {
    "Content-Type": "application/json"
}

# Envia a solicitação POST para o Firebase
response = requests.post(firebase_url, data=data_json, headers=headers)

# Verifica a resposta
if response.status_code == 200:
    print("POST bem-sucedido!")
else:
    print("Falha no POST. Código de status:", response.status_code)
    print(response.text)  # Exibe a resposta de erro, se houver

