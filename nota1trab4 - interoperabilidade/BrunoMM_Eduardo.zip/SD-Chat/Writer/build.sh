# apt install curl
# apt install libcurl4-openssl-dev
# apt install g++
rm -r bin/Linux
mkdir bin/Linux
g++ src/main.cpp -Wall -Wextra -lcurl -lm -o Writer
mv Writer bin/Linux
