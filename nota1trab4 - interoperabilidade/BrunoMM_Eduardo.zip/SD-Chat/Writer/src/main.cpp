#include <iostream>
#include <string>

#include <curl/curl.h>

#ifndef FALSE
#define FALSE 0
#endif

#define FIREBASE_URL "https://sd-chat-775f8-default-rtdb.firebaseio.com/messages.json"

class CurlHandle {
    CURL *curl;
	
	static size_t WriteDataCallback(char *data, size_t size, size_t count, void *arg) {
		std::string *payload = (std::string *)arg;
		payload->append(std::string(data, data + (size * count)));
		
		// std::cout << *payload << std::endl;
		
		return size * count;
	}
	
public:
    CurlHandle() {
        curl = curl_easy_init();
        if (!curl) {
            std::cout << "ERROR: Failed to initialize curl!" << std::endl;
            exit(1);
        }
    }

    ~CurlHandle() {
        curl_easy_cleanup(curl);
    }

    void Post(std::string url, std::string data) {
		curl_easy_setopt(curl, CURLOPT_URL, url.c_str()); 
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, &WriteDataCallback);
		
		std::string payload;
		curl_easy_setopt(curl, CURLOPT_WRITEDATA, &payload);
		
		// curl_easy_setopt(curl,CURLOPT_POST,1L);
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data.c_str());

        CURLcode res = curl_easy_perform(curl);
        if (res != CURLE_OK) {
            std::cout << "ERROR: Failed to perform HTTP request!" << std::endl;
            std::cout << curl_easy_strerror(res) << std::endl;
            exit(1);
        }
    }
};

std::string GenerateJson(std::string& user, std::string& text) {
    return "{ \"user\": \"" + user + "\", \"text\": \"" + text + "\" }";
}

int main(int argc, char *argv[]) {
    CurlHandle curl = CurlHandle();

    std::cout << "Username: ";

    std::string user;
    std::getline(std::cin, user);

    std::cout << std::endl;
    while (true) {
        std::cout << "> ";

        std::string text;
        std::getline(std::cin, text);
		
		if (text == "/exit") {
			break;
		}

        std::string json = GenerateJson(user, text);

        curl.Post(FIREBASE_URL, json);
    }

    return 0;
}
