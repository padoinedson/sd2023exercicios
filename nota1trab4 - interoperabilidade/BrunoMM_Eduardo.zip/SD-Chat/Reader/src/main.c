#include <stdlib.h>
#include <stdio.h>

#define BJ_IMPLEMENTATION
#include <BlueJSON.h>

#include <curl/curl.h>

#ifdef _WINDOWS
#include <Windows.h>
#else
#include <unistd.h>
#define Sleep(x) usleep((x)*1000)
#endif

#ifndef FALSE
#define FALSE 0
#endif

#define FIREBASE_URL "https://sd-chat-775f8-default-rtdb.firebaseio.com/messages.json"

bj_list_node *bj_list_node_at(bj_list *list, size_t index) {
    bj_list_node *node = list->start;
    for (size_t i = 0; i < index && node != NULL; i++) {
        node = node->next;
    }

    return node;
}

struct buffer {
    char *data;
    size_t len;
};

void buffer_cat_str(struct buffer *buffer, const char *str, size_t len) {
    buffer->data = realloc(buffer->data, buffer->len + len + 1);
    memcpy(buffer->data + buffer->len, str, len);
    buffer->len += len;
    buffer->data[buffer->len] = '\0';
}

size_t write_payload_callback(char *data, size_t size, size_t count, void *arg) {
    // printf("DEBUG: size = %u; count = %u; data = %s\n", size, count, data);

    struct buffer *payload = arg;
    buffer_cat_str(payload, data, size * count);

    return size * count;
}

bj_value *request_json(CURL *curl, const char *url) {
    curl_easy_setopt(curl, CURLOPT_URL, url); 
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_payload_callback);
	
    struct buffer payload = {0};
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &payload);

    char error_buffer[CURL_ERROR_SIZE];
    curl_easy_setopt(curl, CURLOPT_ERRORBUFFER, error_buffer);

    CURLcode res = curl_easy_perform(curl);
    if (res != CURLE_OK) {
        printf("ERROR: Failed to perform HTTP request!\n");
		printf(curl_easy_strerror(res));
		
		free(payload.data);
	
        return NULL;
    }
	
    bj_value *json = bj_read_text(payload.data);
	
    free(payload.data);

    return json;
}

void print_message(bj_object *message) {
    bj_string *user = bj_object_find(message, "user")->string;
    bj_string *text = bj_object_find(message, "text")->string;

    printf("%s> %s\n", user->text, text->text);
}

int main(int argc, char *argv[]) {
    CURL *curl = curl_easy_init();
    if (!curl) {
        printf("ERROR: Failed to initialize curl!\n");
        exit(1);
    }

    size_t messages_count = 0;
    while (1) { 
        bj_value *json = request_json(curl, FIREBASE_URL);
		if (!json || json->type == BJ_NULL) {			
			Sleep(1000);
			
			continue;
		}
		
        bj_object *messages = json->object;

        bj_list_node *first_new_message_node = bj_list_node_at(messages->items, messages_count);

        // Printar as novas mensagens
        for (bj_list_node *node = first_new_message_node; node != NULL; node = node->next) {
            bj_object *message = ((bj_value *)node->data)->object;
            print_message(message);

            messages_count++;
        }

        bj_value_destroy(json);
        
        // Pausar o processo por 1 segundo pra não sobrecarregar o servidor
        Sleep(1000);
    }

    curl_easy_cleanup(curl);

    return 0;
}
