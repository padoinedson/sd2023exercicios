# apt install curl
# apt install libcurl4-openssl-dev
# apt install gcc
rm -r bin/Linux
mkdir bin/Linux
gcc src/main.c -Wall -Wextra -Ivendor/BlueJSON/include -lcurl -lm -o Reader
mv Reader bin/Linux
