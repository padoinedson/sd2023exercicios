apt install curl
apt install libcurl4-openssl-dev
apt install g++
apt install gcc

cd Reader
./build.sh

cd ../Writer
./build.sh

