import requests

# URL da base de dados Firebase
firebase_url = "https://trabalho2-padoin-default-rtdb.firebaseio.com/"

# Faz uma requisição GET para obter os dados
response = requests.get(firebase_url + ".json")

# Verifica se a requisição foi bem-sucedida
if response.status_code == 200:
    data = response.json()  # Converte a resposta para um dicionário Python
    print(data)
else:
    print("Erro ao obter dados:", response.status_code)