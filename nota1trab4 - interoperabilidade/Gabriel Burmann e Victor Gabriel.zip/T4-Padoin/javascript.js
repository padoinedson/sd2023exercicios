import { createInterface } from 'readline';
import fetch from 'node-fetch';

const rl = createInterface({
  input: process.stdin,
  output: process.stdout
});

const firebaseUrl = 'https://trabalho2-padoin-default-rtdb.firebaseio.com/trabalho-avaliativo.json';


  rl.question('Nome: ', (name) => {
    rl.question('Idade: ', (age) => {
      rl.question('Número de Telefone: ', (phone) => {
        const userData = {
          nome: name,
          idade: age,
          telefone: phone
        };

        const jsonData = JSON.stringify(userData);

        // Envia os dados para o Firebase
        fetch(firebaseUrl, {
          method: 'POST',
          body: jsonData,
          headers: {
            'Content-Type': 'application/json'
          }
        })
        .then(response => response.json())
        .then(data => {
          console.log('Dados enviados com sucesso:', data);
          rl.close();
        })
        .catch(error => {
          console.error('Erro ao enviar os dados:', error);
          rl.close();
        });
      });
    });
  });

