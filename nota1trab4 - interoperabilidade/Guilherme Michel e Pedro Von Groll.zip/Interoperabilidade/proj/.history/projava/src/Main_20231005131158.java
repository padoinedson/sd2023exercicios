import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;

public class Main {
    public static void main(String[] args) {
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Qual nome da pasta que você quer acessar(Jogo): ");
            String id = reader.readLine();
            String urlString = "https://fireprojeto23-default-rtdb.firebaseio.com/" + id + ".json";

            // Crie uma URI a partir da string da URL
            URI uri = new URI(urlString);

            // Obtenha uma URL da URI
            URL url = uri.toURL();

            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            int responseCode = conn.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                StringBuilder response;
                try (BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {

                    String inputLine;
                    response = new StringBuilder();
                    while ((inputLine = in.readLine()) != null) {
                        response.append(inputLine);
                    }
                }
                String jsonData = response.toString();
                System.out.println(jsonData);
            } else {
                System.out.println("Falha na requisição HTTP com código de resposta: " +
                        responseCode);
            }
        } catch (IOException | URISyntaxException e) {
            e.printStackTrace();
        }
    }
}
