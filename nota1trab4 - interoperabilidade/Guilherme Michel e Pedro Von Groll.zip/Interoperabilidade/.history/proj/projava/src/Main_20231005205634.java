
//importando bibliotecas
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;

public class Main {
    public static void main(String[] args) {
        try { // nome da pasta concatenado com URL do db e é inserido na variavel urlString
            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in)); // para ler o nome da pasta
            System.out.print("Qual nome da pasta que você quer acessar(Jogo): ");
            String id = reader.readLine();
            String urlString = "https://fireprojeto23-default-rtdb.firebaseio.com/" + id + ".json";

            // Crie uma URI a partir da string da URL
            URI uri = new URI(urlString);
            // Obtenha uma URL da URI
            URL url = uri.toURL();

            HttpURLConnection conn = (HttpURLConnection) url.openConnection(); // abertura de conexão HTTP para url
            conn.setRequestMethod("GET"); // conexão é configurada como pedido GET
            int responseCode = conn.getResponseCode(); // obtem codigo de resposta HTTP da conexão
            if (responseCode == HttpURLConnection.HTTP_OK) {
                StringBuilder response; // se a resposta for ok, le os dados e armazena em StringBuildes

                // manipula exceções relacionada entrada/saida (IOException) e a crianção da URI
                // (URISyntaxException)
                try (BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {

                    String inputLine;
                    response = new StringBuilder();
                    while ((inputLine = in.readLine()) != null) {
                        response.append(inputLine);
                    }
                }
                String jsonData = response.toString();
                System.out.println(jsonData);
            } else {
                System.out.println("Conexão com HTTP falhou: errorcode " +
                        responseCode);
            }
        } catch (IOException | URISyntaxException e) {
            e.printStackTrace();
        }
    }
}
