import firebase_admin
from firebase_admin import credentials
from firebase_admin import db

# Configure as credenciais
cred = credentials.Certificate(r"C:\Users\lolmi\Desktop\2023-2\SIST. DISTRI - QUI\fireprojeto2023.json")
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://fireprojeto23-default-rtdb.firebaseio.com/'
})

# Solicitar informações ao usuário
nome_jogo = input("Digite o jogo: ")
tipo_jogo = input("Digite o tipo do jogo: ")


# Envie as informações para o Firebase
ref = db.reference('/Jogo')  # Use a referência apropriada para armazenar jogos
new_jogo = {
    'nome': nome_jogo,
    'tipo': tipo_jogo,
}
ref.push(new_jogo)

print("Informações sobre o jogo encaminhadas para o Firebase.")
