# Importação bibliotecas
import firebase_admin #interface python que interage com Firebase
from firebase_admin import credentials #parte da biblioteca que lida com autenticação
from firebase_admin import db #usado para acessar o banco de dados

# Credenciais pra conseguir acessar o firebase ->JSON com privatekey...
# Acusar o caminho onde o JSON criado na criação do db foi salvo
cred = credentials.Certificate(r"C:\Users\lolmi\Desktop\2023-2\SIST. DISTRI - QUI\fireprojeto2023.json")
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://fireprojeto23-default-rtdb.firebaseio.com/'
}) #inicialização do aplicativo FIrebase com credenciais fornecidas designando um db especifico

# Usuário informa o que é pedido pra salvar na pasta criada no firebase
nome_jogo = input("Digite o nome do jogo: ")
tipo_jogo = input("Digite o tipo do jogo: ")


# Envie as informações para o Firebase
ref = db.reference('/Jogo')  # criando e usando referência ao local no db pra armazenar
new_jogo = { #dicionario python com as inf inseridas
    'nome': nome_jogo,
    'tipo': tipo_jogo,
}
ref.push(new_jogo) #add dicionario como um nó no db, enviando para o firebase
print("Informações sobre o jogo encaminhadas para o Firebase.") #notifica o usário que seus inputs foram salvos