package javaapplication1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class JavaApplication1 {

    public static void main(String[] args) {
        try {
            String urlString = "https://projetot4sd-default-rtdb.firebaseio.com/nomes.json";
            URL url = new URL(urlString);

            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            int responseCode = conn.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                StringBuilder response;

                try (BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {

                    String inputLine;
                    response = new StringBuilder();
                    while ((inputLine = in.readLine()) != null) {
                        response.append(inputLine);
                    }
                }
                System.out.println(response.toString());
            } else {
                System.out.println("Conexão falhou");
            }
        } catch (IOException e) {
            System.out.println(e);
        }
    }
}