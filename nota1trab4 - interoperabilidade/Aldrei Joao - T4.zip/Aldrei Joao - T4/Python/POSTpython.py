import firebase_admin
from firebase_admin import credentials
from firebase_admin import db

cred = credentials.Certificate(r"C:\Users\jpgon\OneDrive\Documents\pyt4\projetot4sd-firebase-adminsdk-ujuv7-9a1cf5365c.json")
firebase_admin.initialize_app(cred, {'databaseURL': 'https://projetot4sd-default-rtdb.firebaseio.com/'})

ref = db.reference('/nomes') 
time = { 
    'nome 1': 'Aldrei',
    'nome 2': 'Joao',
}
ref.push(time)
print("Dados foram encaminhados.")
