var firebaseConfig = {
    apiKey: "AIzaSyA3wRBK8Axd-cClnNaOYg1hhUH8hDD-Z-U",
    authDomain: "nome-7eaf2.firebaseapp.com",
    databaseURL: "https://nome-7eaf2-default-rtdb.firebaseio.com",
    projectId: "nome-7eaf2",
    storageBucket: "nome-7eaf2.appspot.com",
    messagingSenderId: "272170780482",
    appId: "1:272170780482:web:6a2e92f41b22c9ab71aadb"
  };
  firebase.initializeApp(firebaseConfig);
  
  var database = firebase.database();
  
  function get() {
    var id = document.getElementById('id').value;
    var item_ref = database.ref('itens/' + id);

    item_ref.on('value', function(snapshot) {
      var data = snapshot.val();
      
      alert("color: "+data.color+
            "\nprice: "+data.price+
            "\nsize: "+data.size);

      console.log(data);
    });
    
  }