export const mock = {
  "grupos": [
      {
          "nome": "Desenvolvedores JS",
          "descricao": "Grupo para desenvolvedores JavaScript discutirem técnicas, frameworks e melhores práticas.",
          "categoria": "Programação",
          "link": "https://chat.whatsapp.com/ficticio123456"
      },
      {
          "nome": "Fotógrafos do Brasil",
          "descricao": "Compartilhe suas fotos, discuta técnicas e encontre parceiros para sessões fotográficas.",
          "categoria": "Fotografia",
          "link": "https://chat.whatsapp.com/ficticio789012"
      },
      {
          "nome": "Treinos de Corrida",
          "descricao": "Dicas de treinos, maratonas e saúde para entusiastas de corrida.",
          "categoria": "Esportes",
          "link": "https://chat.whatsapp.com/ficticio345678"
      },
      {
          "nome": "Receitas Saudáveis",
          "descricao": "Compartilhe e aprenda novas receitas para uma alimentação saudável.",
          "categoria": "Culinária",
          "link": "https://chat.whatsapp.com/ficticio901234"
      },
      {
          "nome": "Amantes de Gatos",
          "descricao": "Para todos que amam gatos e querem compartilhar fotos, histórias e dicas de cuidado.",
          "categoria": "Animais de Estimação",
          "link": "https://chat.whatsapp.com/ficticio567890"
      },
      {
          "nome": "Fotógrafos do Brasil",
          "descricao": "Compartilhe suas fotos, discuta técnicas e encontre parceiros para sessões fotográficas.",
          "categoria": "Fotografia",
          "link": "https://chat.whatsapp.com/ficticio789012"
      },
      {
          "nome": "Treinos de Corrida",
          "descricao": "Dicas de treinos, maratonas e saúde para entusiastas de corrida.",
          "categoria": "Esportes",
          "link": "https://chat.whatsapp.com/ficticio345678"
      },
      {
          "nome": "Receitas Saudáveis",
          "descricao": "Compartilhe e aprenda novas receitas para uma alimentação saudável.",
          "categoria": "Culinária",
          "link": "https://chat.whatsapp.com/ficticio901234"
      },
      {
          "nome": "Amantes de Gatos",
          "descricao": "Para todos que amam gatos e querem compartilhar fotos, histórias e dicas de cuidado.",
          "categoria": "Animais de Estimação",
          "link": "https://chat.whatsapp.com/ficticio567890"
      },
      {
          "nome": "Fotógrafos do Brasil",
          "descricao": "Compartilhe suas fotos, discuta técnicas e encontre parceiros para sessões fotográficas.",
          "categoria": "Fotografia",
          "link": "https://chat.whatsapp.com/ficticio789012"
      },
      {
          "nome": "Treinos de Corrida",
          "descricao": "Dicas de treinos, maratonas e saúde para entusiastas de corrida.",
          "categoria": "Esportes",
          "link": "https://chat.whatsapp.com/ficticio345678"
      },
      {
          "nome": "Receitas Saudáveis",
          "descricao": "Compartilhe e aprenda novas receitas para uma alimentação saudável.",
          "categoria": "Culinária",
          "link": "https://chat.whatsapp.com/ficticio901234"
      },
      {
          "nome": "Amantes de Gatos",
          "descricao": "Para todos que amam gatos e querem compartilhar fotos, histórias e dicas de cuidado.",
          "categoria": "Animais de Estimação",
          "link": "https://chat.whatsapp.com/ficticio567890"
      }
  ]
}
