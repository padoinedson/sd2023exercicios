import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyCW0LWLtn8ud--oJsnix1JEt45Rq5vcs80",
  authDomain: "exe2-get-post.firebaseapp.com",
  projectId: "exe2-get-post",
  storageBucket: "exe2-get-post.appspot.com",
  messagingSenderId: "817129274164",
  appId: "1:817129274164:web:5a957e635cf9cdde598361"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app)

export { app, db }