import { Button } from "@/components/ui/button";

import { collection, getDocs } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { useEffect, useState } from "react";

interface Group {
  nome: string;
  descricao: string;
  categoria: string;
  link: string;
}

export function App() {
  const [groups, setGroups] = useState<Group[]>([]);

  useEffect(() => {
    const fetchData = async (): Promise<Group[]> => {
      const querySnapshot = await getDocs(collection(db, "grupos"));
      const groupsData = querySnapshot.docs.map((doc) => doc.data() as Group);
      return groupsData;
    };

    fetchData().then((response) => {
      console.log(JSON.stringify(response));
      setGroups(response);
    });
  }, []);

  return (
    <main className="p-8">
      <div className="max-w-6xl mx-auto">
        <div className="mt-8 grid grid-cols-3 gap-8">
          {groups.map((group) => (
            <div
              className="border p-4 rounded-md flex-col flex items-center w-full"
              key={group.nome}
            >
              <h2 className="text-lg font-medium mt-2">{group.nome}</h2>
              <small className="bg-green-100 px-4 py-1 rounded-sm mt-2">
                {group.categoria}
              </small>
              <p className="h-full mt-3 text-base">{group.descricao}</p>
              <Button className="mt-6" onClick={() => window.open(group.link)}>
                Acessar grupo
              </Button>
            </div>
          ))}
        </div>
      </div>
    </main>
  );
}
