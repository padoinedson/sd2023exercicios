## Execução do projeto FrontEnd

## Requisitos

- Node.js v16.0.0 ou superior.

1. **Instalar dependências:**

Se estiver usando `npm`:

\```
npm install
\```

## Executando o Projeto

Utilize o comando abaixo para iniciar o servidor de desenvolvimento do Vite.

\```
npm run dev
\```