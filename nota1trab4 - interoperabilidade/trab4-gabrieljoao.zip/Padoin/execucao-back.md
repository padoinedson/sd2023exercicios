## Execução do projeto Backend

## Requisitos

- Python3 e PIP.

1. **Instalar dependências:**

\```
pip install firebase-admin
\```

## Executando o Projeto

Utilize o comando abaixo para executar o código.
Ao executar o código a requisição será feita conforme o conteúdo do objeto "group"

\```
py post.py
\```

Caso não conseguir executar localmente, execute via google colab com o link 
    https://colab.research.google.com/drive/1lTfk2P5Lz7vjkQmv2HSv3w8n0ofTbNwi