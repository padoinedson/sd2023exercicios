let form = document.getElementById('form');
let inputName = document.getElementById('name');
let inputValue = document.getElementById('value');
let searchButton = document.getElementById('search');
let resultList = document.getElementById('results-list');
let url = 'https://aula0509-64002-default-rtdb.firebaseio.com/teste/.json';
//let url = 'https://trab-6a2b1-default-rtdb.firebaseio.com/trabalho/trab.json';
// let url = 'https://teste-f499c-default-rtdb.firebaseio.com/testes/teste.json';

form.addEventListener('submit', function(e) {
    e.preventDefault();
    let data = {
        "name": inputName.value,
        "value": inputValue.value
    }

    fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
    }).then(function(response) {
        console.log(response);
    });
});

searchButton.addEventListener('click', function(e) {
    e.preventDefault();
    fetch(url, {
        method: "GET", // *GET, POST, PUT, DELETE, etc.
        headers: {
          "Content-Type": "application/json",
        },
    }).then(function(response) {
        response.json().then(function(res) {
            resultList.innerHTML = ``;

            Object.values(res).forEach((d) => {
                var div = document.createElement('div');
                div.classList.add('result');
                Object.entries(d).forEach(entry => {
                    var span = document.createElement('span');
                    span.classList.add('data');
                    const [key, value] = entry;
                    span.innerHTML = `${key}: ${value}`;
                    div.appendChild(span)
                });
                resultList.appendChild(div);
            });
        });
    });
})