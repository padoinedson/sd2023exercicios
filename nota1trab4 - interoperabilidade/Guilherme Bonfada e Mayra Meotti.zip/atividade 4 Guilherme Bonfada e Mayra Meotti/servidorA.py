import requests

firebase_url = 'https://atividade4-6683c-default-rtdb.firebaseio.com/final/teste.json/'

nova_mensagem = {
    'id': '4',
    'nome': 'padoin',
    'idade': '20 anos',
}

response = requests.post(firebase_url, json=nova_mensagem)

if response.status_code == 200:
    print('Mensagem atualizada com sucesso!')
else:
    print(f'Erro ao atualizar a mensagem: {response.status_code} - {response.text}')