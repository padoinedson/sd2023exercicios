const express = require('express');
const app = express();

const bodyParser = require('body-parser');

const API_BASE = 'https://aulasd-1b0ae-default-rtdb.firebaseio.com';

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

app.post('/:file', async (req, res) => {
    //"Nome do arquivo" que vai ser criado no Firebase
    const { file } = req.params;

    const { name } = req.query;

    //Conteúdo que vai ser enviado ao Firebase
    const json = {
        aula: 'Sistemas Distribuídos',
        data: new Date(),
        name,
    };

    await fetch(`${API_BASE}/${file}.json`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(json),
    });

    res.send('JSON enviado com sucesso');
});

app.listen(3000, () => {
    console.log('API running on port 3000')
});