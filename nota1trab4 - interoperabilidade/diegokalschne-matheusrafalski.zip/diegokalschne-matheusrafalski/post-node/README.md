## Para executar
1. Ter o Node instalado

2. Rodar `npm install` para instalar as dependências

3. Executar `node ./index.js` para rodar a API