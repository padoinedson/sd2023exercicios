from fastapi import FastAPI
import uvicorn
import requests



app = FastAPI()

def start_server(host="127.0.0.1",
                 port=8000,
                 reload=True):
    uvicorn.run("main:app",
                host=host,
                port=port,
                reload=reload)


if __name__ == "__main__":
    start_server()



@app.get('/')
async def get():
    body = requests.get("https://aulasd-1b0ae-default-rtdb.firebaseio.com/aulajson.json")
    return body.json()
