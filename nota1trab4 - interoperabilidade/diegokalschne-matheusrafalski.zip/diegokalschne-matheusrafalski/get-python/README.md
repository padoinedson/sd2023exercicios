# python-api
API em Python para pegar arquivos no Firebase

## Para Executar
1. Ter o Python instalado
2. Executar `python main.py` para executar o projeto