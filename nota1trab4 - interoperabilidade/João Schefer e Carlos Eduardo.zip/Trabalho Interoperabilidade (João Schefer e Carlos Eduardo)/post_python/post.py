import firebase_admin
from firebase_admin import credentials
from firebase_admin import db

# Configurar as credenciais
cred = credentials.Certificate(r"/home/joao/Documents/trabalho_padoin/trabalho_padoin.json")
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://projetotrabalho-568f2-default-rtdb.firebaseio.com/'
})

# Solicitar as informações ao usuário
marca_carro = input("Digite a marca do carro: ")
modelo_carro = input("Digite o modelo do carro: ")
ano_carro = input("Digite o ano do carro: ")

# Envie as informações para o Firebase
ref = db.reference('/carros')
novo_carro = {
    'marca': marca_carro,
    'modelo': modelo_carro,
    'ano': ano_carro
}
ref.push(novo_carro)

print("Informações do carro foram enviadas para o Firebase.")
