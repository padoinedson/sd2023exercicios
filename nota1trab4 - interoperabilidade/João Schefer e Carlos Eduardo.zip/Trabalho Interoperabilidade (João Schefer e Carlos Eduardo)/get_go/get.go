package main

// importar os pacotes necessários
import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"os"
)

// definida uma estrutura Usr com três campos: Marca, Modelo e Ano. 
// essa estrutura será usada para armazenar os dados JSON recuperados da resposta HTTP.
type Usr struct {
	Ano    string `json:"ano"`
	Marca  string `json:"marca"`
	Modelo string `json:"modelo"`
}

// essa função busca dados JSON de uma URL específica
// decodifica esses dados em uma estrutura de dados Go
// se houver algum problema durante o processo, ela mostra o erro
func fetchData(id string) (map[string]Usr, error) {
	url := "https://projetotrabalho-568f2-default-rtdb.firebaseio.com/" + id + ".json"

	resp, err := http.Get(url)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("Erro: Status Code %d", resp.StatusCode)
	}

	data, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return nil, err
	}

	var usr map[string]Usr
	if err := json.Unmarshal(data, &usr); err != nil {
		return nil, err
	}

	return usr, nil
}

// essa parte do código interage com o usuário para obter um nome de pasta
// busca os dados JSON associados a esse nome,
// formata os dados de forma organizada
// imprime os dados formatados no console
// se tiver um erro durante o processo, é exibido mensagens de erro
func main() {
	var id string
	fmt.Print("Nome da pasta: ")
	fmt.Scanf("%s", &id)

	usr, err := fetchData(id)
	if err != nil {
		fmt.Println(err)
		os.Exit(1)
	}

	prettyJSON, err := json.MarshalIndent(usr, "", "  ")
	if err != nil {
		fmt.Println(err)
		os.Exit(1)
	}

	fmt.Printf("Dados JSON formatados:\n%s\n", prettyJSON)
}
