#include <netinet/in.h>
#include <stdlib.h>
#include <stdio.h>

#define enderecoIP "127.0.0.1"
#define PORT 7000

int main (void) {


	int 	sock_id,
		numero;

	struct 	sockaddr_in address;

	system("clear");

	sock_id = socket(AF_INET,SOCK_STREAM,0);

	if(sock_id > 0)
		printf("\nSocket criado \n ");
	else {
		printf("\nErro criando socket");
		exit(1);
	}


	address.sin_family=AF_INET;
	address.sin_addr.s_addr=inet_addr(enderecoIP);
	//address.sin_addr.s_addr=INADDR_ANY;
	address.sin_port=htons(PORT);

	connect(sock_id,(struct sockaddr *)&address,sizeof(address));

	if (connect==0)
		printf("\nConexao nao aceita \n");
	else
		printf("\nConexao  aceita\n\n");

	printf("\nDigite um valor: ");
        scanf("%d",&numero);

	send(sock_id,&numero,(1 * sizeof(int)),0);

        recv(sock_id,&numero,(1 * sizeof(int)),0);

        printf("\nValor incrementado:  %d\n\n\n",numero);

	close(sock_id);
    //
}












