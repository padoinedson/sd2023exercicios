#include <netinet/in.h>
#include <stdlib.h>
#include <stdio.h>

#define PORT 7000


int main (long argc, char **argv) {

	int 	numero,
		sock_id1,
		sock_id2,
		addrlen, 
		run;	
	
	struct sockaddr_in address;

	system("clear");

	sock_id1 = socket(AF_INET,SOCK_STREAM,0);

	if(sock_id1 > 0)
		printf("\nSocket criado \n ");
	else {
		printf("\nErro criando socket");
		exit(1);
	}

	address.sin_family=AF_INET;
	address.sin_addr.s_addr=INADDR_ANY;
	address.sin_port=htons(PORT);


	if (bind(sock_id1,(struct sockaddr *)&address,sizeof(address))==0) {
		printf("\nSocket Binding\n");
	}
	else {
	       	printf("\nErro no Binding Sockt");
		exit(0);
	}

	listen(sock_id1,5);

	addrlen=sizeof(struct sockaddr_in);


	run = 4;

	while(run){

		printf("\nAguardando %d conexoes \n",run);
		run --;

		sock_id2 = accept(sock_id1,(struct sockaddr *)&address,&addrlen);

		if (sock_id2 > 0) 
		    printf("\nConexao aceita\n");


		recv(sock_id2,&numero,(1 * sizeof(int)),0);

		printf("\nValor recebido:  %d\n",numero);

		numero ++;

                send(sock_id2,&numero,(1 * sizeof(int)),0);

        }
	close(sock_id2);
	close(sock_id1);
}










